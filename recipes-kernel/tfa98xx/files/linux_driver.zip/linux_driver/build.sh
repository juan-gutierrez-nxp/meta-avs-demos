#!/bin/bash

# Make sure git repositories are checked out:
#
# git clone ssh://nxp71646@www.collabnet.nxp.com:29418/linux
# git checkout max1-2-v3.14-dev
#
# git clone ssh://nxp71646@www.collabnet.nxp.com:29418/plma_hostsw
# git checkout dev
#
# git clone ssh://nxp71646@www.collabnet.nxp.com:29418/plma_config
# git checkout dev
#
# Run this script from the top level directory:
#
# ./plma_hostsw/linux_driver/build.sh <target> <device>
# <target> : target BBB, when not specifed only compile test
# <device> : target TFA device, must be specified if target is specified
#

if [ $# -lt 2 ]
then
  echo "Usage: $0 <target> <device>"
  exit 0
fi
BBB=$1
TFA_DEVICE=$2

# Check if git repositories are available:
if [ ! -d linux ]
then
  echo "Error, directory linux does not excist"
  exit 1
fi
if [ ! -d plma_hostsw ]
then
  echo "Error, directory plma_hostsw does not excist"
  exit 1
fi

if [ $BBB ]
then

  if [ ! -d plma_config ]
  then
    echo "Error, directory plma_config does not excist"
    exit 1
  fi

  # Check access to target
  ssh -q root@$BBB "echo hello > /dev/null"
  if [ $? -ne 0 ]
  then
    echo "Error accessing target $BBB"
    exit 1
  fi
  
  # Check device is valid
  if [ ! -d plma_config/$TFA_DEVICE ]
  then
     echo "Invalid device $TFA_DEVICE"
     exit 1
  fi
fi

export ARCH=arm 
export CROSS_COMPILE=arm-linux-gnueabihf- 

# build kernel, modules and device tree
cd linux
rm -rf mods_install/
make bbb-max2_defconfig &&\
make  LOCALVERSION= -j6 zImage dtbs &&\
make  LOCALVERSION= INSTALL_MOD_PATH=mods_install -j6 modules &&\
make  LOCALVERSION= INSTALL_MOD_PATH=mods_install modules_install

if [ $? -ne 0 ]
then
  echo "Building of kernel, modules and/or device tree failed"
  exit 1
fi

if [[ $BBB ]]
then
  scp arch/arm/boot/zImage root@$BBB:/boot/uboot &&\
  scp arch/arm/boot/dts/am335x-boneblack-tfa98xx.dtb root@$BBB:/boot/uboot/dtbs/am335x-boneblack.dtb &&\
  rsync -r mods_install/lib root@$BBB:/

  if [ $? -ne 0 ]
  then
    echo "Copying of kernel, modules and/or device tree failed"
    exit 1
  fi
fi


cd ../plma_hostsw

# avoid conflicts between kernel and user space objects
# (may happen when user space is broken in previous build)
scons -j6 arm=1 -c

# build tfa98xx kernel module
cd linux_driver
make KDIR=../../linux

if [ $? -ne 0 ]
then
  echo "Building of tfa98xx kernel module failed"
  exit 1
fi


if [ $BBB ]
then
  scp snd-soc-tfa98xx.ko root@$BBB:/lib/modules/3.14.19/kernel/sound/soc/codecs/ &&\
  ssh root@$BBB "/sbin/depmod -a"

  if [ $? -ne 0 ]
  then
    echo "Copying of tfa98xx kernel module failed"
    exit 1
  fi
fi

# clean up to avoid conflicts between kernel and user space objects
make KDIR=../../linux clean
cd ..

# Create climax for ARM 
scons -j6 arm=1 extra_ccflags=-DI2C_FORCE

if [ $? -ne 0 ]
then
  echo "Building of climax failed"
  exit 1
fi

if [[ $BBB ]]
then
  scp climax root@$BBB:/usr/bin &&\
  scp libtfa98xx.so root@$BBB:/usr/lib

  if [ $? -ne 0 ]
  then
    echo "Copying of climax failed"
    exit 1
  fi
fi

# clean up to avoid conflicts between kernel and user space objects
scons -j6 arm=1 -c

### Copying of container file already done in test script
#if [ $BBB ]
#then
#  # Copy config
#  cd ../plma_config
#  ssh root@$BBB "mkdir -p /lib/firmware/tfa98/$TFA_DEVICE/" &&\
#  scp $TFA_DEVICE/*.cnt root@$BBB:/lib/firmware/tfa98/$TFA_DEVICE/

#  if [ $? -ne 0 ]
#  then
#    echo "Copying of container file failed"
#    exit 1
#  fi
#
#  # FIXME:
#  ssh root@$BBB "rm /lib/firmware/tfa98xx.cnt ; ln -s /lib/firmware/tfa98/$TFA_DEVICE/stereo_N1B3_bbb.cnt /lib/firmware/tfa98xx.cnt"
#fi

if [ $BBB ]
then
  # reboot target for the kernel and device tree changes to be effective
  ssh root@$BBB "reboot"

  # wait for the target to be available again
  echo "Waiting for target to be rebooted"
  i="0"
  while [ $i -lt 20 ]
  do
    sleep 5
    ssh -q root@$BBB "echo hello > /dev/null"
    if [ $? -eq 0 ]
    then
       break
    fi
    echo "."
    i=$[$i+1]
  done
fi


