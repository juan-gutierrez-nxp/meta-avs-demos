#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0x75e611af, __VMLINUX_SYMBOL_STR(module_layout) },
	{ 0xe56a9336, __VMLINUX_SYMBOL_STR(snd_pcm_format_width) },
	{ 0x1752b133, __VMLINUX_SYMBOL_STR(i2c_master_send) },
	{ 0x45f38634, __VMLINUX_SYMBOL_STR(device_remove_bin_file) },
	{ 0xb00214d7, __VMLINUX_SYMBOL_STR(kmalloc_caches) },
	{ 0x12da5bb2, __VMLINUX_SYMBOL_STR(__kmalloc) },
	{ 0xe4689576, __VMLINUX_SYMBOL_STR(ktime_get_with_offset) },
	{ 0xf9a482f9, __VMLINUX_SYMBOL_STR(msleep) },
	{ 0xfbc74f64, __VMLINUX_SYMBOL_STR(__copy_from_user) },
	{ 0x528c709d, __VMLINUX_SYMBOL_STR(simple_read_from_buffer) },
	{ 0x286026fe, __VMLINUX_SYMBOL_STR(generic_file_llseek) },
	{ 0xe84a3160, __VMLINUX_SYMBOL_STR(debugfs_create_dir) },
	{ 0x349cba85, __VMLINUX_SYMBOL_STR(strchr) },
	{ 0x51eafc8e, __VMLINUX_SYMBOL_STR(param_ops_int) },
	{ 0x67c2fa54, __VMLINUX_SYMBOL_STR(__copy_to_user) },
	{ 0x97255bdf, __VMLINUX_SYMBOL_STR(strlen) },
	{ 0x43a53735, __VMLINUX_SYMBOL_STR(__alloc_workqueue_key) },
	{ 0x41f5c3b0, __VMLINUX_SYMBOL_STR(i2c_del_driver) },
	{ 0xde1bbf08, __VMLINUX_SYMBOL_STR(dev_printk) },
	{ 0xb756debb, __VMLINUX_SYMBOL_STR(i2c_transfer) },
	{ 0xe0b5ab5c, __VMLINUX_SYMBOL_STR(gpio_to_desc) },
	{ 0x6b06fdce, __VMLINUX_SYMBOL_STR(delayed_work_timer_fn) },
	{ 0x74fc27ce, __VMLINUX_SYMBOL_STR(snd_soc_add_codec_controls) },
	{ 0x7c4ef70, __VMLINUX_SYMBOL_STR(snd_soc_dapm_new_controls) },
	{ 0xfa2bcf10, __VMLINUX_SYMBOL_STR(init_timer_key) },
	{ 0x4a8907de, __VMLINUX_SYMBOL_STR(cancel_delayed_work_sync) },
	{ 0x35e6e1e8, __VMLINUX_SYMBOL_STR(mutex_unlock) },
	{ 0xa7fa5e3e, __VMLINUX_SYMBOL_STR(regmap_read) },
	{ 0x33164747, __VMLINUX_SYMBOL_STR(debugfs_create_file) },
	{ 0xa2cde71d, __VMLINUX_SYMBOL_STR(debugfs_remove_recursive) },
	{ 0xe2d5255a, __VMLINUX_SYMBOL_STR(strcmp) },
	{ 0x2a08d0d6, __VMLINUX_SYMBOL_STR(simple_attr_read) },
	{ 0xcca7ffdd, __VMLINUX_SYMBOL_STR(input_event) },
	{ 0x275ef902, __VMLINUX_SYMBOL_STR(__init_waitqueue_head) },
	{ 0xedbd2412, __VMLINUX_SYMBOL_STR(devm_gpio_free) },
	{ 0xdac67a22, __VMLINUX_SYMBOL_STR(snd_soc_dapm_add_routes) },
	{ 0x9435c1d2, __VMLINUX_SYMBOL_STR(snd_pcm_hw_constraint_mask64) },
	{ 0x62a79a6c, __VMLINUX_SYMBOL_STR(param_ops_charp) },
	{ 0xfa2a45e, __VMLINUX_SYMBOL_STR(__memzero) },
	{ 0x5f754e5a, __VMLINUX_SYMBOL_STR(memset) },
	{ 0x83130f62, __VMLINUX_SYMBOL_STR(cancel_delayed_work) },
	{ 0xf706285b, __VMLINUX_SYMBOL_STR(default_llseek) },
	{ 0x11089ac7, __VMLINUX_SYMBOL_STR(_ctype) },
	{ 0x7e947924, __VMLINUX_SYMBOL_STR(dev_err) },
	{ 0xe3a262e3, __VMLINUX_SYMBOL_STR(snd_pcm_hw_constraint_list) },
	{ 0x76f6c5ef, __VMLINUX_SYMBOL_STR(kmalloc_order) },
	{ 0xbdd9e3e5, __VMLINUX_SYMBOL_STR(__mutex_init) },
	{ 0x27e1a049, __VMLINUX_SYMBOL_STR(printk) },
	{ 0x20c55ae0, __VMLINUX_SYMBOL_STR(sscanf) },
	{ 0x71c90087, __VMLINUX_SYMBOL_STR(memcmp) },
	{ 0x84b183ae, __VMLINUX_SYMBOL_STR(strncmp) },
	{ 0xd3cd6b0d, __VMLINUX_SYMBOL_STR(mutex_lock) },
	{ 0x6220b4a2, __VMLINUX_SYMBOL_STR(crc32_le) },
	{ 0x8c03d20c, __VMLINUX_SYMBOL_STR(destroy_workqueue) },
	{ 0x1e6d26a8, __VMLINUX_SYMBOL_STR(strstr) },
	{ 0xccca6d4d, __VMLINUX_SYMBOL_STR(simple_attr_release) },
	{ 0x8e865d3c, __VMLINUX_SYMBOL_STR(arm_delay_ops) },
	{ 0x73945a24, __VMLINUX_SYMBOL_STR(simple_open) },
	{ 0xc85338b6, __VMLINUX_SYMBOL_STR(request_firmware_nowait) },
	{ 0x1352f55c, __VMLINUX_SYMBOL_STR(devm_gpio_request_one) },
	{ 0x2196324, __VMLINUX_SYMBOL_STR(__aeabi_idiv) },
	{ 0x45a47af9, __VMLINUX_SYMBOL_STR(i2c_register_driver) },
	{ 0xb449402d, __VMLINUX_SYMBOL_STR(_dev_info) },
	{ 0xe72b7a00, __VMLINUX_SYMBOL_STR(kmem_cache_alloc) },
	{ 0x9963a089, __VMLINUX_SYMBOL_STR(queue_delayed_work_on) },
	{ 0x3bd1b1f6, __VMLINUX_SYMBOL_STR(msecs_to_jiffies) },
	{ 0x8d08cc4c, __VMLINUX_SYMBOL_STR(input_register_device) },
	{ 0xcfdadb3e, __VMLINUX_SYMBOL_STR(devm_regmap_init_i2c) },
	{ 0x3292533c, __VMLINUX_SYMBOL_STR(input_free_device) },
	{ 0xde6fb46c, __VMLINUX_SYMBOL_STR(of_get_named_gpio_flags) },
	{ 0xd59dae3, __VMLINUX_SYMBOL_STR(device_create_bin_file) },
	{ 0xcc5005fe, __VMLINUX_SYMBOL_STR(msleep_interruptible) },
	{ 0x6ed68daa, __VMLINUX_SYMBOL_STR(snd_soc_unregister_codec) },
	{ 0x68a24153, __VMLINUX_SYMBOL_STR(snd_pcm_format_physical_width) },
	{ 0x37a0cba, __VMLINUX_SYMBOL_STR(kfree) },
	{ 0x9d669763, __VMLINUX_SYMBOL_STR(memcpy) },
	{ 0x7c7719a3, __VMLINUX_SYMBOL_STR(input_unregister_device) },
	{ 0xd5477209, __VMLINUX_SYMBOL_STR(gpiod_to_irq) },
	{ 0xf9e73082, __VMLINUX_SYMBOL_STR(scnprintf) },
	{ 0x5606903d, __VMLINUX_SYMBOL_STR(gpiod_set_raw_value_cansleep) },
	{ 0xefd6cf06, __VMLINUX_SYMBOL_STR(__aeabi_unwind_cpp_pr0) },
	{ 0xb81960ca, __VMLINUX_SYMBOL_STR(snprintf) },
	{ 0x5239a4c9, __VMLINUX_SYMBOL_STR(snd_soc_register_codec) },
	{ 0x93e3940, __VMLINUX_SYMBOL_STR(devm_kmalloc) },
	{ 0x2770f6b8, __VMLINUX_SYMBOL_STR(devm_request_threaded_irq) },
	{ 0xfa54866b, __VMLINUX_SYMBOL_STR(regmap_write) },
	{ 0x4f561efa, __VMLINUX_SYMBOL_STR(simple_attr_open) },
	{ 0x28ece6eb, __VMLINUX_SYMBOL_STR(release_firmware) },
	{ 0xd41b9dde, __VMLINUX_SYMBOL_STR(simple_attr_write) },
	{ 0xe914e41e, __VMLINUX_SYMBOL_STR(strcpy) },
	{ 0x36fc28f9, __VMLINUX_SYMBOL_STR(input_allocate_device) },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("i2c:tfa98xx");

MODULE_INFO(srcversion, "9C23174548319727B77D7F8");
