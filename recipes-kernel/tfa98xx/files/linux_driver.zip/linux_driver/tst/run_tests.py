import sys
import time
import threading
import unittest
import xmlrunner

from test_devicetree import TestDeviceTree
from test_module import TestModule
from test_sysfs import TestSysfs
from test_debugfs import TestDebugfs
from test_audio_mixer import TestAudioMixer
from test_audio_pcm import TestAudioPCM
from test_audio_volume import TestAudioVolume
from test_input_device import TestInputDevice
from test_no_start import TestNoStartModuleOption
from test_audio_signals import TestAudioSignals
from test_interrupts1 import TestInterrupts1
from test_interrupts2 import TestInterrupts2
from test_climax_sysfs import TestClimaxSysfs
from test_timing_profile import TestTimingProfile
from test_reset import TestReset

stop_watchdog = 0

def run_watchdog():
	wd = open("/dev/watchdog", "w+")

	while stop_watchdog == 0:
		wd.write("\n")
		wd.flush()
		time.sleep(5)

	wd.write("V") # "Magic Close"
	wd.close()

if __name__ == "__main__":

	loader = unittest.TestLoader()
	suite = unittest.TestSuite((
		loader.loadTestsFromTestCase(TestDeviceTree),
		loader.loadTestsFromTestCase(TestModule),
		loader.loadTestsFromTestCase(TestSysfs),
		loader.loadTestsFromTestCase(TestDebugfs),
		loader.loadTestsFromTestCase(TestAudioMixer),
		loader.loadTestsFromTestCase(TestAudioPCM),
		loader.loadTestsFromTestCase(TestAudioVolume),
		loader.loadTestsFromTestCase(TestInputDevice),
		loader.loadTestsFromTestCase(TestNoStartModuleOption),
		loader.loadTestsFromTestCase(TestAudioSignals),
		loader.loadTestsFromTestCase(TestInterrupts1),
		loader.loadTestsFromTestCase(TestInterrupts2),
		loader.loadTestsFromTestCase(TestClimaxSysfs),
		loader.loadTestsFromTestCase(TestTimingProfile),
		loader.loadTestsFromTestCase(TestReset),
	))

	xml_output = False
	if len(sys.argv) > 1:
		xml_output = (sys.argv[1] == "xml")

	if xml_output:
		runner = xmlrunner.XMLTestRunner(output='test-reports')
	else:
		runner = unittest.TextTestRunner(verbosity=2)


	# Start the watchdog thread
	t = threading.Thread(target=run_watchdog, name="Watchdog")
	t.setDaemon(True)
	stop_watchdog = 0
	t.start()

	ret = not runner.run(suite).wasSuccessful()

	# Stop the watchdog thread
	stop_watchdog = 1
	t.join()

	sys.exit(ret)

