import ctypes

class tinyalsa:
	class __mixer_function:
		GET_VALUE = 1
		GET_RANGE_MIN = 2
		GET_RANGE_MAX = 3
		GET_NUM_ENUMS = 4
		GET_NUM_VALUES = 5

 	def __init__(self):
		self.so = ctypes.CDLL("./libtinyalsa_support.so")

	def maxlen_ctl_name(self):
		return self.so.ta_maxlen_ctl_name()

	def cardname_to_index(self, name):
		return self.so.ta_cardname_to_index(str(name))

	def mixer_ctl_get_num_ctls(self, device):
		return self.so.ta_mixer_ctl_get_num_ctls(device)

	def mixer_ctl_get_num_values(self, device, name):
		return self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_NUM_VALUES)

	def mixer_ctl_get_num_enums(self, device, name):
		return self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_NUM_ENUMS)

	def mixer_ctl_get_range_min(self, device, name):
		return self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_RANGE_MIN)

	def mixer_ctl_get_range_max(self, device, name):
		return self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_RANGE_MAX)

	def mixer_ctl_set_value(self, device, name, value):
		return self.so.ta_mixer_ctl_set_value(device, str(name), value)

	def mixer_ctl_get_value(self, device, name):
		return self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_VALUE)

	def mixer_ctl_set_enum(self, device, name, value):
		return self.so.ta_mixer_ctl_set_enum(device, str(name), str(value))

	def mixer_ctl_get_enums(self, device, name):
		enums = []
		item_max_len = self.maxlen_ctl_name() + 1
		item  = ((ctypes.c_char) * item_max_len)()
		nr =  self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_NUM_ENUMS)
		for i in range(0, nr):
			self.so.ta_mixer_ctl_get_enum_string(device, str(name), i, ctypes.byref(item), item_max_len)
			enums.append(item.value)
		return enums

	# TODO: get value type from tinyalsa and support controls with values other then int
	def mixer_ctl_set_values(self, device, name, values):
		nr = self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_NUM_VALUES)
		if nr < 0:
			return nr

		assert len(values) >= nr, "number of values smaller then the number of mixer control values"

		values_c = (ctypes.c_int * nr)()
		for idx, value in enumerate(values):
			values_c[idx] = value
		ctypes.cast(values_c, ctypes.POINTER(ctypes.c_int))
		return self.so.ta_mixer_ctl_set_array(device, str(name), values_c, nr)

	# TODO: get value type from tinyalsa and support controls with values other then int
	def mixer_ctl_get_values(self, device, name):
		nr = self.so.ta_mixer_ctl_get_x(device, str(name), self.__mixer_function.GET_NUM_VALUES)
		if nr <= 0:
			return []
		values = (ctypes.c_int * nr)()
		ctypes.cast(values, ctypes.POINTER(ctypes.c_int))
		self.so.ta_mixer_ctl_get_array(device, str(name), values, nr)
		return [values[i] for i in range(nr)]

