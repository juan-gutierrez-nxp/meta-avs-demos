/*
 * Copyright 2015-2017 NXP Semiconductors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <tinyalsa/asoundlib.h>

/* #define DEBUG */

#ifndef SNDRV_CTL_ELEM_ID_NAME_MAXLEN
#define SNDRV_CTL_ELEM_ID_NAME_MAXLEN 44
#endif

#define GET_VALUE 1
#define GET_RANGE_MIN 2
#define GET_RANGE_MAX 3
#define GET_NUM_ENUMS 4
#define GET_NUM_VALUES 5

int ta_maxlen_ctl_name(void)
{
	return SNDRV_CTL_ELEM_ID_NAME_MAXLEN;
}

int ta_cardname_to_index(const char *name)
{
	int index = -1;

	for (int i=0; (i < 10) && (index == -1); i++) {
		struct mixer *m;
		m = mixer_open(i);
		if (m == NULL)
			break;
		if (strcmp(name, mixer_get_name(m)) == 0)
			index = i;
		mixer_close(m);
	}

	return index;
}

int ta_mixer_ctl_get_num_ctls(const unsigned int card)
{
	struct mixer *mixer;
	int ret = 0;

	mixer = mixer_open(card);
	if (!mixer) {
#ifdef DEBUG
		fprintf(stderr, "%s: Failed to open mixer: card=%u\n", __func__, card);
#endif
		return -1;
	}

	ret = mixer_get_num_ctls(mixer);

	mixer_close(mixer);

	return ret;
}

int ta_mixer_setup(const unsigned int card, const char *name, struct mixer **mixer, struct mixer_ctl **ctl)
{
	int err = 0;

	*mixer = mixer_open(card);
	if (!(*mixer)) {
#ifdef DEBUG
		fprintf(stderr, "%s: Failed to open mixer: card=%u\n", __func__, card);
#endif
		err = -1;
	}

	if (!err) {
		*ctl = mixer_get_ctl_by_name(*mixer, name);
		if (!(*ctl)) {
#ifdef DEBUG
			fprintf(stderr, "%s: Invalid mixer control: %s\n", __func__, name);
#endif
			err = -2;
		}
	}
	return err;
}

int ta_mixer_ctl_set_enum(const unsigned int card, const char *name, const char *value)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);

	if (!err) {
		err = mixer_ctl_set_enum_by_string(ctl, value);
		if (err < 0) {
#ifdef DEBUG
			fprintf(stderr, "%s: Error, seting enum value %s\n", __func__, value);
#endif
			err =  -3;
		}
	}

	mixer_close(mixer);

	return err;
}

int ta_mixer_ctl_set_value(const unsigned int card, const char *name, int value)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);

	if (!err) {
		err = mixer_ctl_set_value(ctl, 0, value);
		if (err < 0) {
#ifdef DEBUG
			fprintf(stderr, "%s: Error, seting value %d\n", __func__, value);
#endif
			err =  -3;
		}
	}

	mixer_close(mixer);

	return err;
}

int ta_mixer_ctl_get_x(const unsigned int card, const char *name, const unsigned int selector)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);

	if (!err) {
		if (selector == GET_VALUE)
			err = mixer_ctl_get_value(ctl, 0);
		else if (selector == GET_RANGE_MIN)
			err = mixer_ctl_get_range_min(ctl);
		else if (selector == GET_RANGE_MAX)
			err = mixer_ctl_get_range_max(ctl);
		else if (selector == GET_NUM_ENUMS)
			err = mixer_ctl_get_num_enums(ctl);
		else if (selector == GET_NUM_VALUES)
			err = mixer_ctl_get_num_values(ctl);
	}

	mixer_close(mixer);

	return err;
}

int ta_mixer_ctl_get_enum_string(const unsigned int card, const char *name, const int id, char *item, const int size)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);

	if (!err) {
		err = snprintf(item, size, "%s", mixer_ctl_get_enum_string(ctl, id));
		if (err < 0)
			err = -3;
	}

	mixer_close(mixer);

	return err;
}

int ta_mixer_ctl_get_array(const unsigned int card, const char *name, void *p_array, int num)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);

	if (!err) {
		err = mixer_ctl_get_array(ctl, p_array, num);
		if (err < 0) {
#ifdef DEBUG
			fprintf(stderr, "%s: Error, geting array for control %s\n", __func__, name);
#endif
			err =  -3;
		}
	}

	mixer_close(mixer);

	return err;
}

int ta_mixer_ctl_set_array(const unsigned int card, const char *name, void *p_array, int num)
{
	struct mixer *mixer;
	struct mixer_ctl *ctl;
	int err = 0;

	err = ta_mixer_setup(card, name, &mixer, &ctl);
	if (!err) {

		/* integer min/max check missing in mixer_ctl_set_array() */
		enum mixer_ctl_type type = mixer_ctl_get_type(ctl);
		if (type == MIXER_CTL_TYPE_INT) {
			int *ptr = (int *)p_array;
			int min = mixer_ctl_get_range_min(ctl);
			int max = mixer_ctl_get_range_max(ctl);

			for (int i=0; i<num; i++) {
				if ((ptr[i] < min) || (ptr[i] > max)) {
					mixer_close(mixer);
					return -EINVAL;
				}
			}
		}

		err = mixer_ctl_set_array(ctl, p_array, num);
		if (err < 0) {
#ifdef DEBUG
			fprintf(stderr, "%s: Error, seting array for control %s\n", __func__, name);
#endif
			err =  -3;
		}
	}

	mixer_close(mixer);

	return err;
}
