import unittest
import time
import re

import common
import device_info
import audio_support
import climax_support

class TestClimaxSysfs(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)
	climax = climax_support.climax('/lib/firmware/'+ common.cnt_file)

	##### support functions #####

	def record_live_data(self, ms_interval, count):

		# start the audio clock by playing silence
		self.audio.start_silence_loop(48000, 2, 16, 300)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)
			live_datas = self.climax.record(ms_interval, count)

		finally:
			# stop the audio clock
			self.audio.stop_silence_loop()

		return live_datas

	def get_model_data(self, model):
		#  Enable clock by playing silence
		self.audio.start_silence_loop(48000, 2, 16, 100)

		try:
			#  Set short timeout to synchronize with playback in background
			time.sleep(4)
			values, error = self.climax.get_model_dump(model)

			# Initialize variables
			idx = 0  # This will select channel for data
			data = [[], []]  # Placeholder for channel(s) data (by default stereo)
			# Go through all lines, when device is matched switch channel
			for num, line in enumerate(values):
				m = re.match("Device\[([0-9])\]:", line)
				if m:
					idx = int(m.group(1));  # Change channel to idx

				# Add only lines with numbers to current channel
				if re.match("[0-9]+\,[0-9]+\.[0-9]+", line):
					data[idx].append(line)

		finally:
			#  Stop audio clock
			self.audio.stop_silence_loop()

		return data[0], data[1], error.splitlines()

	##### tests #####

	def setUp(self):
		common.load_modules()

	def tearDown(self):
		common.remove_modules()

	def test_live_data_available(self):

		if not self.info.dsp_device():
			print "no live data without DSP"
			return

		live_datas = self.record_live_data(200, 10)

		for data in live_datas[1:]:
			value_sum = 0.0
			for value in data:
				value_sum += abs(float(value))
			self.assertNotEqual(int(value_sum), 0, "live data is 0")

	def test_live_data_speaker_resistance(self):

		if not self.info.dsp_device():
			print "no live data without DSP"
			return

		if self.info.tfa_family() != 1:
			print "speakerResistance only available for TFA1 devices"
			return

		live_datas = self.record_live_data(200, 100)

		idx = live_datas[0].index("speakerResistance")
		for data in live_datas[1:]:
			resistance = float(data[idx])
			# 8 ohm +/- 20%
			self.assertTrue(resistance > (8 - 1.6), "Resistance value too low: " + str(resistance))
			self.assertTrue(resistance < (8 + 1.6), "Resistance value too high: " + str(resistance))

	def test_live_data_speaker_temperature(self):

		if not self.info.dsp_device():
			print "no live data without DSP"
			return

		if self.info.tfa_family() != 1:
			print "speakerTemp only available for TFA1 devices"
			return

		live_datas = self.record_live_data(200, 100)

		idx = live_datas[0].index("speakerTemp")
		temp = float((live_datas[1])[idx])
		for data in live_datas[1:]:
			prev_temp = temp
			temp = float(data[idx])
			self.assertTrue(temp > 0, "speaker is freezing (speakerTemp=" + str(temp) + ")")
			self.assertTrue(temp < 100, "speaker is burning (speakerTemp=" + str(temp) + ")")
			self.assertTrue(abs(temp-prev_temp) < (prev_temp/2), "more then 50% change in temperature: " + str(prev_temp) + " " + str(temp))

	def test_mtp_mbdrc(self):

		if not self.info.dsp_device():
			print "no DSP skipping test"
			return

		if self.info.tfa_family() != 2:
			print "No TFA2 skipping test"
			return

		values = self.climax.get_bitfield("type_bits_fw").values()
		for value in values:
			self.assertEqual(int(value), 1, "MBDRC is not enabled")


	def test_dumpmodel_x(self):
		if not self.info.dsp_device():
			print "no DSP test skipped"
			return

		left_data, right_data, error = self.get_model_data(self.climax.MODEL_X)

		self.assertTrue(not error, msg="Error detected during dumping x model!")
		self.assertFalse(left_data == [], msg="No data found in dump")
		if self.info.get_nr_devices() > 1:
			self.assertFalse(right_data == [], msg="No data in right channel")

	def test_dumpmodel_z(self):
		if not self.info.dsp_device():
			print "no DSP test skipped"
			return

		left_data, right_data, error = self.get_model_data(self.climax.MODEL_Z)

		self.assertTrue(not error, msg="Error detected during dumping x model!")
		self.assertFalse(left_data == [], msg="No data found in dump")
		if self.info.get_nr_devices() > 1:
			self.assertFalse(right_data == [], msg="No data in right channel")

if __name__ == '__main__':
	unittest.main()

