platform_module  = "snd-soc-bbb-nxp-tfa"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

alsa_audiocard_name = "TFA9912"

tfa_device = "9912"
tfa_device_id = "13"
tfa_cnt_basename = "mono_bbb"
tfa_cnt_aec_profile="music_aec"
tfa_cnt_iv_profile=""

