import unittest

import common

class TestDeviceTree(unittest.TestCase):

	##### support functions #####

	def open_devicetree(self, name):
		file = "/proc/device-tree/sound/" + name
		try:
			f = open(file)
		except IOError:
			self.fail("can not access: " + file)

		return f

	##### tests #####

	def setUp(self):
		pass

	def tearDown(self):
		pass

	def test_devicetree_compatible(self):
		f = self.open_devicetree("compatible")
		compatible = f.readline().rstrip('\0')
		f.close()
		print "compatible = " + compatible
		self.assertEqual(compatible, "nxp,tfa98xx-bbb-audio", "device not correctly specified in device tree")

	def test_devicetree_model(self):
		f = self.open_devicetree("nxp,model")
		nxp_model = f.readline().rstrip('\0')
		f.close()
		print "nxp,model = " + nxp_model
		self.assertEqual(nxp_model, common.alsa_audiocard_name, "nxp,model not correctly specified in device tree")


if __name__ == '__main__':
	unittest.main()

