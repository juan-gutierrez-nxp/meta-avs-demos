import unittest
import time

import common
import device_info
import climax_support
import tinyalsa_support
import audio_support

class TestAudioVolume(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)
	climax = climax_support.climax('/lib/firmware/'+ common.cnt_file)
	tinyalsa = tinyalsa_support.tinyalsa()

	##### support functions #####

	def get_check_bitfield(self, bitfield):
		values = self.climax.get_bitfield(bitfield).values()
		equal = (values[1:] == values[:-1])
		self.assertTrue(equal, "bit fields not equal")
		return int(values[0], 0)

	def set_mixer_enum(self, name, value):
		return self.tinyalsa.mixer_ctl_set_enum(self.card_index, name, value)

	def get_mixer_enums(self, name):
		return self.tinyalsa.mixer_ctl_get_enums(self.card_index, name)

	def set_mixer_values(self, name, values):
		return self.tinyalsa.mixer_ctl_set_values(self.card_index, name, values)

	def get_mixer_values(self, name):
		return self.tinyalsa.mixer_ctl_get_values(self.card_index, name)

	def get_mixer_min(self, name):
		return self.tinyalsa.mixer_ctl_get_range_min(self.card_index, name)

	def get_mixer_max(self, name):
		return self.tinyalsa.mixer_ctl_get_range_max(self.card_index, name)

	def get_mixer_value(self, name):
		return self.tinyalsa.mixer_ctl_get_value(self.card_index, name)

	def get_mixer_enum(self, name):
		return self.get_mixer_enums(name)[self.get_mixer_value(name)]

	def playback_silence(self, samplerate, secs):
		ret = self.audio.play_silence(samplerate, 2, 16, secs)
		self.assertEqual(ret, 0, "Error playback silence")

	# sanity checks, to make sure that device_info is available
	def check_device_info(self):
		if not self.info.device_names:
			self.fail("no devices found in ini file")
		if not self.info.profiles:
			self.fail("no profiles found in ini file")
		if not self.info.vsteps:
			self.fail("no vsteps found in ini file")

	##### tests #####

	def setUp(self):
		common.load_modules()
		self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)
		self.check_device_info()

	def tearDown(self):
		common.remove_modules()

	# test setting the mixer volume when there is no audio playing
	def test_audio_volume_noclock(self):

		name = self.info.device_names[0]
		mixer_label = self.info.application_name

		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")
		for mixer_profile in mixer_profiles:

			# Skip profiles without vstep(s)
			if len(self.info.mixer_steps[mixer_profile]) == 0:
				continue

			for samplerate in self.info.mixer_samplerates[mixer_profile]:

				# playback audio, so profile for samplerate can be set
				self.playback_silence(samplerate, 6)

				swprofil1 = self.get_check_bitfield('SWPROFIL')
				self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
				swprofil2 = self.get_check_bitfield('SWPROFIL')

				cnt_profile = self.info.mixer_to_profile(mixer_profile, samplerate)
				value = self.info.profiles[name].index(cnt_profile)

				# no audio playback, no clock: no change in profile yet
				self.assertEqual(swprofil1, swprofil2, "profile: " + mixer_profile + ": swprofil should not have been changed")

				# playback audio, now the mixer settings should be applied
				self.playback_silence(samplerate, 6)

				swprofil = self.get_check_bitfield('SWPROFIL')

				mixer_profile2 = self.get_mixer_enum(mixer_label + " Profile")
				cnt_profile = self.info.mixer_to_profile(mixer_profile2, samplerate)
				value =  self.info.profiles[name].index(cnt_profile)

				self.assertEqual(value, swprofil-1, mixer_label + " Profile" + " (" + str(value) + ") does not match swprofil-1 (" + str(swprofil-1) + "), samplerate = " + str(samplerate))

				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				min_vol = self.get_mixer_min(volume_ctl)
				max_vol = self.get_mixer_max(volume_ctl)
				nr_steps = (max_vol - min_vol) + 1

				for vol1 in range(min_vol, max_vol+1):
					swvstep1 = self.get_check_bitfield('SWVSTEP')
					vols1 = [vol1] * self.info.get_nr_devices()
					self.set_mixer_values(volume_ctl, vols1)
					swvstep2 = self.get_check_bitfield('SWVSTEP')

					position1 = min_vol + nr_steps - int(swvstep1)

					# no audio playback, no clock: no change in vstep yet
					self.assertEqual(swvstep1, swvstep2, "swvstep should not have been changed")

					# playback audio, now the mixer settings should be applied
					self.playback_silence(samplerate, 6)

					swvstep = self.get_check_bitfield('SWVSTEP')
					position = min_vol + nr_steps - swvstep
					self.assertEqual(vol1, position, volume_ctl + " (" + str(vol1) + ") does not match swvstep position (" + str(position) + " swvstep="+ str(swvstep) + "), samplerate = " + str(samplerate))

					vol_device = self.get_check_bitfield('VOL')
					vol_vstep = self.info.mixer_steps[mixer_profile][nr_steps - 1 - vol1]
					self.assertEqual(vol_vstep, vol_device, "Volume device (" + str(vol_device) + ") and vstep(" + str(vol_vstep) + ") do not match, samplerate = " + str(samplerate))

	# test setting the mixer volume when there is audio playing
	def test_audio_volume_clock(self):

		name = self.info.device_names[0]
		mixer_label = self.info.application_name

		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")
		for mixer_profile in mixer_profiles:

			# Skip profiles without vstep(s)
			if len(self.info.mixer_steps[mixer_profile]) == 0:
				continue

			for samplerate in self.info.mixer_samplerates[mixer_profile]:

				self.audio.start_silence_loop(samplerate, 2, 16, 600)

				# make sure we stop the silence playback thread when something goes wrong
				try:
					time.sleep(4)

					self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
					mixer_profile2 = self.get_mixer_enum(mixer_label + " Profile")
					self.assertEqual(mixer_profile, mixer_profile2, "mixer profile not set correctly")

					time.sleep(40.0/1000.0)

					swprofil = self.get_check_bitfield('SWPROFIL')
					cnt_profile = self.info.mixer_to_profile(mixer_profile2, samplerate)
					value =  self.info.profiles[name].index(cnt_profile)

					self.assertEqual(value, swprofil-1, mixer_label + " Profile" + " (" + str(value) + ") does not match swprofil-1 (" + str(swprofil-1) + "), samplerate = " + str(samplerate))

					volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
					min_vol = self.get_mixer_min(volume_ctl)
					max_vol = self.get_mixer_max(volume_ctl)
					nr_steps = (max_vol - min_vol) + 1

					for vol1 in range(min_vol, max_vol+1):
						vols1 = [vol1] * self.info.get_nr_devices()
						self.set_mixer_values(volume_ctl, vols1)
						vols2 = self.get_mixer_values(volume_ctl)
						self.assertEqual(vols1, vols2, "mixer volume not set correctly")

						time.sleep(40.0/1000.0)

						swvstep = self.get_check_bitfield('SWVSTEP')
						position = min_vol + nr_steps - swvstep
						self.assertEqual(vol1, position, volume_ctl + " (" + str(vol1) + ") does not match swvstep position (" + str(position) + " swvstep="+ str(swvstep) + "), samplerate = "+ str(samplerate))

						vol_device = self.get_check_bitfield('VOL')
						vol_vstep = self.info.mixer_steps[mixer_profile][nr_steps - 1 - vol1]
						self.assertEqual(vol_device, vol_vstep, "Volume device (" + str(vol_device) + ") and vstep(" + str(vol_vstep) + ") do not match, samplerate = " + str(samplerate))

				finally:
					self.audio.stop_silence_loop()


if __name__ == '__main__':
	unittest.main()

