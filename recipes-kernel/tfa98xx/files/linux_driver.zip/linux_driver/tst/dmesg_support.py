import re
import time
import shlex
import subprocess

# Supporting class to access information contained in dmesg
class dmesg:
	# Regular expression to filter profile switch messages from driver
	PROFILE_REGEXP = "\s*\[\s*(.+)\s*\]\s*tfa98xx\s*([0-9]+-[0-9]+):\s*" + \
			 "tfa_dev_start\(([0-9]+)\,([0-9]+)\)\s*time\s*=\s*([0-9]+)\s*us"

	def __init__(self):
		# This will force dmesg to provide time as human readable date (-T)
		self.dmsg_cmd = "dmesg -k -T"

	def extract_profile_sw_time(self):
		# Run dmesg for parsing inputs
		args = shlex.split(self.dmsg_cmd)
		output, error = subprocess.Popen(args, stdout = subprocess.PIPE, \
						stderr = subprocess.PIPE).communicate()
		# Prepare regular expression for multiple matches
		rec = re.compile(dmesg.PROFILE_REGEXP)
		# Get profile switching times
		values = []
		for line in output.splitlines():
			m = rec.match(line)
			if m:
				# (time, device, profile, vstep, delay
				values.append((m.group(1), m.group(2), m.group(3), \
				               m.group(4), m.group(5)))
		return values, error.splitlines()


if __name__ == "__main__":
	print "This is supporting module. Exiting!"

