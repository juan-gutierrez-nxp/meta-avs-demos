import unittest
import time

import common
import device_info
import audio_support
import tinyalsa_support
import dmesg_support

class TestTimingProfile(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:" + common.alsa_audiocard_name)
	tinyalsa = tinyalsa_support.tinyalsa()
	dmesg = dmesg_support.dmesg()

	@classmethod
	def setUpClass(cls):
		# Enable logging of profile switch events
		common.load_modules(trace_lvl = 9)

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### support function #####
	def set_mixer_enum(self, name, value):
		return self.tinyalsa.mixer_ctl_set_enum(self.card_index, name, value)

	def get_mixer_enums(self, name):
		return self.tinyalsa.mixer_ctl_get_enums(self.card_index, name)

	# sanity checks, to make sure that device_info is available
	def check_device_info(self):
		if not self.info.device_names:
			self.fail("no devices found in ini file")
		if not self.info.profiles:
			self.fail("no profiles found in ini file")
		if not self.info.vsteps:
			self.fail("no vsteps found in ini file")

	##### tests #####

	def setUp(self):
		self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)
		self.check_device_info()

	def tearDown(self):
		pass

	def test_profile_timings(self):
		# Get current time, to reject logs before test
		start_time = time.localtime()
		time.sleep(3)  # Wait to be sure that test doesn't start too quickly

		# Gather available profiles
		mixer_label = self.info.application_name
		profiles = self.get_mixer_enums(mixer_label + " Profile")
		self.assertTrue(profiles != [], "There are no profiles in container!")

		# Play audio
		self.audio.start_silence_loop(48000, 2, 16, 100)

		try:
			time.sleep(4)
			# Profile switch
			for prof in profiles:
				self.set_mixer_enum(mixer_label + " Profile", prof)

		finally:
			self.audio.stop_silence_loop()

		# Get logs
		values, errors = self.dmesg.extract_profile_sw_time()
		# Check for errors returned
		self.assertTrue(errors == [], "Dmesg returned errors:" + str(errors))
		# Store results in dictionary
		results = {}
		# Go through logs and reject the ones that are older before test
		logs = filter(lambda v: time.strptime(v[0]) > start_time, values)
		self.assertTrue(logs != [], "There is no profile switch in logs")
		# Get all participating devices
		devices = [(log[1]) for log in logs]
		# Create empty list of values for all devices
		for dev in devices:
			results[dev] = []
		# For each valid log add each value into device list (with time)
		for log in logs:
			results[log[1]].append(float(log[4]))
		# Print avarage time for each device
		print "\nSwitching times:"
		for key, value in results.iteritems():
			avg = sum(value)/len(value)
			print "Device " + str(key) + " with time avg. = " + "%.2f" % avg + " us."
			self.assertTrue(avg != 0, "Switching time shouldn't be 0")


if __name__ == "__main__":
	unittest.main()
