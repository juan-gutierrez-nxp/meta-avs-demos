platform_module  = "snd-soc-bbb-nxp-tfa"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

alsa_audiocard_name = "TFA9888"

tfa_device = "88"
tfa_device_id = tfa_device
tfa_cnt_basename = "stereo_bbb"
tfa_cnt_aec_profile="music_aec"
tfa_cnt_iv_profile=""

