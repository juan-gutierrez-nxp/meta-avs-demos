import unittest

import common
import device_info
import audio_support

# tests Linux kernel interrupts
class TestInterrupts2(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)

	def parse_proc_interrupts(self):
		irqs = []
		fired = []

		proc_intr = '/proc/interrupts'
		f = open(proc_intr)
		for line in f.readlines():
			line = line.strip()
			fields = line.split()
			if fields[0][:3] == 'CPU':
				nr_cpus = len(fields)
				continue

			try:
				irq = int(fields[0].strip(":"))
			except ValueError:
				continue
			else:
				if  fields[-1][:7] == "tfa98xx":
					irqs.append(irq)
					fired.append(sum(int(fields[i]) for i in range(1, 1+nr_cpus)))
		return (irqs, fired)


	##### tests #####

	def setUp(self):
		common.load_modules()

	def tearDown(self):
		common.remove_modules()

	def test_interrupts_available(self):
		if self.info.tfa_family() == 1:
			print "no interrupts for TFA1 family"
			return

		(irqs, fired) = self.parse_proc_interrupts()

		print "irq(s): " + str(irqs)

		nr_dev = self.info.get_nr_devices()
		nr_irq = len(irqs)
		self.assertEqual(nr_irq, nr_dev, "Expected " + str(nr_dev) + " instead of " + str(nr_irq) + " IRQ(s)")

	@unittest.skip("see artf247659")
	def test_interrupts_fired(self):

		# low power interrupts expected for 72
		if self.info.tfa_device != "72":
			print "no interrupts for " + self.info.tfa_device
			return

		(irqs, fired1) = self.parse_proc_interrupts()
		print "interrupt(s) before: " + str(fired1)

		ret = self.audio.play_silence(48000, 2, 16, 5)
		self.assertEqual(ret, 0, "playback error")

		(irqs, fired2) = self.parse_proc_interrupts()
		print "interrupt(s) after: " + str(fired2)

		for idx, fire2 in enumerate(fired2):
			fire1 = fired1[idx]
			self.assertNotEqual(fire1, fire2, "No interrupt(s) occured for IRQ " + str(irqs[idx]))


if __name__ == '__main__':
	unittest.main()

