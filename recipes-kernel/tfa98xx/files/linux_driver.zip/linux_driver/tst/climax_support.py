
import shlex, subprocess

class climax:

    def __init__(self, cnt_file):
        self.cnt_file = cnt_file

    def start(self, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + " --start"
        if slave:
            cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        if "Error" in output:
            return False
	return True

    def stop(self, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + " --stop"
        if slave:
            cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        if "Error" in output:
            return False
	return True

    def reset(self, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + " --reset"
        if slave:
             cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        if "Error" in output:
            return False
        return True

    def get_bitfield(self, bitfield, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + ' ' + bitfield
        if slave:
            cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        list1 = [s.replace('[', '').replace(']', '') for s in shlex.split(output)[::2]]
        list2 = [s.replace(bitfield + ':', '') for s in shlex.split(output)[1::2]]
        return dict(zip(list1, list2))

    def set_bitfield(self, bitfield, value, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + ' ' + bitfield + "=" + str(value)
        if slave:
            cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        if "Error" in output:
            return False
        return True

    def set_reg(self, reg, value, slave=0):
        cmd = 'climax -dsysfs -l'+ self.cnt_file + " -r" + str(reg) + " -w" + str(value)
        if slave:
            cmd += " --slave " + str(slave)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()
        if "Error" in output:
            return False
        return True

    def get_vsteps_tfa2(self, vstep_file):
        cmd = 'climax -b -l'+ vstep_file
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()

        vsteps = []

        for line in output.splitlines():

            if "VOLSEC" in line:
		continue

            if "VOL" in line:
		vol = int(shlex.split(line)[0].replace('VOL=', ''))
		vsteps.append(vol)

        return vsteps

    def get_vsteps_tfa1(self, vstep_file):
        cmd = 'climax -b -l'+ vstep_file
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()

        vsteps = []

        for line in output.splitlines():
            if "att:" in line:
                voldB = float(shlex.split(line)[1].replace('att:', ''))
                vol = min(-2 * int(voldB), 255)
		vsteps.append(vol)

        return vsteps

    # Model definition for modeldump function
    MODEL_X = 'x'
    MODEL_Z = 'z'

    def get_model_dump(self, model):
	assert(model)
	cmd = 'climax -dsysfs -l' + self.cnt_file + ' --dumpmodel=' + model
	args = shlex.split(cmd)
	output, error = subprocess.Popen(args, stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()

	# Strip already first line
	values = output.splitlines()[1:]

	return values, error

    def record(self, ms_interval, count):
	assert(count>0)
        cmd = 'climax -dsysfs -l'+ self.cnt_file + ' --record=' + str(ms_interval) + ' --count=' + str(count)
        args = shlex.split(cmd)
        output,error = subprocess.Popen(args,stdout = subprocess.PIPE, stderr = subprocess.PIPE).communicate()

	# recording interval time: 200 ms
	# Found Device[0]: left at 0x36.
	# Found Device[1]: right at 0x37.
	skip = 1
	all_lines = output.splitlines()
	for line in all_lines[:5]:
		if "Found Device" in line:
			skip = skip + 1

	# skip first lines
	lines = output.splitlines()[skip:]

	# labels on first line
	data = []
	data.append(lines[0].split(",")[0:-1])

	# actual data
	for line in lines[1:]:
		data.append(line.split(",")[1:-1])

	return data

