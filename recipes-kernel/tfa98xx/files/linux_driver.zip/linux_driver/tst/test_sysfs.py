import unittest
import os
import os.path
import errno

import common

class TestSysfs(unittest.TestCase):

	def find_devices(self):
		devices = []
		for path,dirs,files in os.walk('/sys/bus/i2c/devices/'):
			for d in dirs:
				p = os.path.join(path, d)
				f = "name"
				nf = open(os.path.join(p, f), "r")
				name = nf.readline()
				nf.close()
				if name[:-1] in common.driver_names:
					[bus,addr] = os.path.basename(p).split("-")
					#print "found tfa98xx: bus=" + bus +" addr=0x%x" % int(addr, 16) + " (" + p +")"
					devices.append("/sys/bus/i2c/devices/" + bus + "-" + addr + "/")
		return devices

	@classmethod
	def setUpClass(cls):
		common.load_modules()

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### tests #####

	def setUp(self):
		self.device_paths = self.find_devices()

	def tearDown(self):
		pass

	def test_sysfs_supported(self):
		print "sysfs path(s): " + str(self.device_paths)
		self.assertTrue(len(self.device_paths) > 0, "tfa98xx driver sysfs support not found")

	def test_sysfs_dirs(self):
		for device_path in self.device_paths:
			self.assertTrue(os.path.exists(device_path + "reg"))
			self.assertTrue(os.path.exists(device_path + "rw"))

	def test_sysf_readid(self):
		for device_path in self.device_paths:
			reg = open(device_path + "reg", "wb", 0)
			rw = open(device_path + "rw", "rwb", 0)

			reg.write(b"\x03")
			bytes = rw.read(2)

			reg.close()
			rw.close()

			print "device id: 0x" + bytes.encode('hex')
			self.assertEqual(bytes[1].encode('hex'), common.tfa_device_id, "can not read device id via sysfs")

	def test_sysfs_read_reg(self):
		for device_path in self.device_paths:
			err = 0
			try:
				reg = open(device_path + "reg", "r", 0)
				reg.read(2) # fails with Permission denied
				reg.close()
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EACCES, "should not be able to read reg entry")

	def test_sysfs_write_invalid_reg(self):
		for device_path in self.device_paths:
			err = 0
			try:
				reg = open(device_path + "reg", "wb", 0)
				reg.write(b"\x03\x03") # fails with Invalid argument
				reg.close()
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EINVAL, "should not be able to read reg entry")


if __name__ == '__main__':
	unittest.main()

