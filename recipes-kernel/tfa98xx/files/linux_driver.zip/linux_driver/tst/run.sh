#!/bin/sh

# Setup ssh key on target:
# cat ~/.ssh/id_rsa.pub | ssh root@$TARGET "mkdir -p ~/.ssh && cat >>  ~/.ssh/authorized_keys"

# Install pyalsaaudio on target:
# git clone https://github.com/larsimmisch/pyalsaaudio.git
# cd pyalsaaudio
# git checkout 0.8.2
# cd ..
# scp -r pyalsaaudio root@$TARGET:
# ssh root@$TARGET "cd pyalsaaudio ;  ./setup.py  install"

# Install xml-reporting on target:
# scp ~/unittest-xml-reporting-2.1.0.tar.gz ~/six-1.10.0.tar.gz root@$TARGET:
# ssh root@$TARGET "gzip -d <six-1.10.0.tar.gz | tar xvf -"
# ssh root@$TARGET "cd six-1.10.0/ ; python setup.py install"
# ssh root@$TARGET "gzip -d <unittest-xml-reporting-2.1.0.tar.gz | tar xvf -"
# ssh root@$TARGET "cd unittest-xml-reporting-2.1.0/ ; python setup.py install"

if [ $# -lt 3 ]
then
  echo "Usage: $0 <target> <device> <variant> <xml reporting>"
  exit 1
fi

TARGET=$1
DEVICE=$2
VARIANT=$3
XML_ENABLE=$4

# wait max 30 min for target to return when running tests
# (to prevent blocking Jenkins when target reboots due to a watchdog reset)
TARGET_TIMEOUT=1800

if [ $# -eq 4 ]
then
  XML_ENABLE=$4
else
  XML_ENABLE=0
fi

# Clean up test reports before trying to acces the target
# (so Jenkins does not find old test reports if the target is not accessible)
if [ $XML_ENABLE -ne 0 ]
then
  rm -rf test-reports
fi

# Check access to target
ssh -q root@$TARGET "echo hello > /dev/null"
if [ $? -ne 0 ]
then
  echo "Error accessing target $TARGET"
  exit 1
fi

# Check if the configuration is defined
if [ ! -f "tfa_config-$DEVICE$VARIANT.py" ]
then
  echo "Error, configuration $DEVICE$VARIANT does not exist"
  exit 1
fi

CONFIGS=../../../plma_config/

# Check if the configuration is defined
if [ ! -d $CONFIGS ]
then
  echo "Error, directory $CONFIGS does not exist"
  exit 1
fi

DIR=test

echo "Setting up target $TARGET for configuration $DEVICE $VARIANT"

ssh -q root@$TARGET "mkdir -p $DIR/$DEVICE"

scp -q common.py device_info.py timeout_decorator.py climax_support.py audio_support.py gpio_support.py dmesg_support.py run_tests.py root@$TARGET:/root/$DIR
scp -q test_audio_mixer.py test_audio_pcm.py test_debugfs.py test_devicetree.py test_module.py test_sysfs.py test_input_device.py test_audio_volume.py test_no_start.py test_audio_signals.py test_interrupts1.py test_interrupts2.py test_climax_sysfs.py test_reset.py test_timing_profile.py root@$TARGET:/root/$DIR

# tinyalsa support library
scp -q tinyalsa_support.py tinyalsa_support.c root@$TARGET:/root/$DIR
ssh -q root@$TARGET "cd $DIR ; gcc -Wall -Wextra -std=c99 -Os -shared -fPIC tinyalsa_support.c -ltinyalsa -o libtinyalsa_support.so"

# device specific configuration
scp -q tfa_config-$DEVICE$VARIANT.py root@$TARGET:/root/$DIR/tfa_config.py

scp -q -r $CONFIGS/$DEVICE/vstep root@$TARGET:/root/$DIR/$DEVICE
scp -q $CONFIGS/$DEVICE/*.ini root@$TARGET:/root/$DIR/$DEVICE/
scp -q $CONFIGS/$DEVICE/*.cnt root@$TARGET:/lib/firmware/tfa98/$DEVICE/


echo "Starting the tests on target"

# execute the tests
if [ $XML_ENABLE -ne 0 ]
then
  timeout --foreground $TARGET_TIMEOUT ssh -q root@$TARGET "cd $DIR ; rm -rf test-reports ; python run_tests.py xml"
  scp -r root@$TARGET:/root/$DIR/test-reports .
else
  timeout --foreground $TARGET_TIMEOUT ssh -q root@$TARGET "cd $DIR ; python run_tests.py"
fi

