platform_module  = "snd-soc-bbb-nxp-max2"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

alsa_audiocard_name = "TFA9888"

tfa_device = "88"
tfa_cnt_basename = "stereo_N1C_bbb"
