class gpio:

	__sysfs_gpio_path = "/sys/class/gpio/"

	def __init__(self, nr):
		self.__gpio_nr = nr
		f = open(self.__sysfs_gpio_path + "export", "w")
		f.write(str(self.__gpio_nr))
		f.close()

	def __del__(self):
		f = open(self.__sysfs_gpio_path + "unexport", "w")
		f.write(str(self.__gpio_nr))
		f.close()

	def read(self):
		name = self.__sysfs_gpio_path + "gpio" + str(self.__gpio_nr) + "/value"
		f = open(name, "r")
		value = f.read().replace("\n", "")
		f.close()
		return int(value)

	def write(self, value):
		name = self.__sysfs_gpio_path + "gpio" + str(self.__gpio_nr) + "/value"
		f = open(name, "w")
		f.write(str(value))
		f.close()

	def set_dir(self, value):
		name = self.__sysfs_gpio_path + "gpio" + str(self.__gpio_nr) + "/direction"
		f = open(name, "w")
		f.write(value)
		f.close()

	def get_dir(self):
		name = self.__sysfs_gpio_path + "gpio" + str(self.__gpio_nr) + "/direction"
		f = open(name, "r")
		value = f.read().replace("\n", "")
		f.close()
		return value
