import unittest
import threading
import time
import numpy as np

import common
import device_info
import tinyalsa_support
import audio_support

class TestAudioSignals(unittest.TestCase):

	tinyalsa = tinyalsa_support.tinyalsa()
	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)

	# parameters
	sine_freq = [440.0, 523.25]
	driver_min_channels = 2

	##### support functions #####

	def set_mixer_enum(self, name, value):
		return self.tinyalsa.mixer_ctl_set_enum(self.card_index, name, value)

	def set_mixer_values(self, name, values):
		return self.tinyalsa.mixer_ctl_set_values(self.card_index, name, values)

	def get_mixer_max(self, name):
		return self.tinyalsa.mixer_ctl_get_range_max(self.card_index, name)

	def zero_crossing_rate(self, data):
		signs = np.sign(data)
		signs[signs == 0] = -1
		return 1.0 * len(np.where(np.diff(signs))[0])/len(data)

	def detect_sine_frequency(self, audio, fs):
		freq = []

		if audio.ndim == 2:
			for ch in range(audio.shape[1]):
				freq.append(fs * self.zero_crossing_rate(audio[:,ch]) / 2)
		else:
			freq.append(fs * self.zero_crossing_rate(audio) / 2)

		return freq

	def play_sine(self, f0, A, secs, fs, output_channels):
		input_channels = len(f0)
		output_channels = max(output_channels, self.driver_min_channels)

		t = np.arange(0, secs, 1.0/fs)
		x = np.empty((t.size * output_channels,), dtype=t.dtype)
		for ch in range(input_channels):
			x[ch::output_channels] = A * np.sin(2.0 * np.pi * f0[ch] * t) * 32767 # 16 bit signed

		ret = self.audio.play(x.astype(np.int16), fs, output_channels, 16, secs)
		self.assertEqual(ret, 0, "Playback error")

	def capture_audio(self, fs, channels, secs):
		channels = max(channels, self.driver_min_channels)

		data2 = self.audio.capture(fs, channels, 16, secs)
		self.assertNotEqual(data2, "", "Capture error")

		audio = np.fromstring(data2, dtype="<h")
		if channels > 1:
			return audio.reshape(audio.size/channels, channels)
		else:
			return audio

	def audio_loopback(self, mixer_profile, input_channels, output_channels):
		mixer_label = self.info.application_name

		for samplerate in self.info.mixer_samplerates[mixer_profile]:

			print "samplerate: " + str(samplerate) + " Hz"

			# set max volume
			volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
			vol = self.get_mixer_max(volume_ctl)
			vols = [vol] * self.info.get_nr_devices()
			self.set_mixer_values(volume_ctl, vols)

			# set profile
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# playback a sine in a thread
			sines = []
			for ch in range(input_channels):
				sines.append(self.sine_freq[ch])
			t = threading.Thread(target=self.play_sine, name="play_sine", args=(sines, 1.0, 10, samplerate, output_channels))
			t.start()
			time.sleep(6)

			# capture the resulting signal
			audio = self.capture_audio(samplerate, output_channels, 2)
			t.join()

			# calculate the frequency of the sine in the captured signal
			freqs = self.detect_sine_frequency(audio, samplerate)

			# check the frequency of the sine +/-10%
			for ch in range(output_channels):
				freq = freqs[ch]
				print "channel " + str(ch) + ": sine frequency = " + str(freq) + " Hz"
				ch2 = ch / (output_channels/input_channels)
				self.assertTrue(freq > (self.sine_freq[ch2] - self.sine_freq[ch2]/10), "ch" + str(ch) + ": for samplerate " + str(samplerate) + " sine frequency " + str(freq) + " is lower then expected (" + str(self.sine_freq[ch2]) + ")")
				self.assertTrue(freq < (self.sine_freq[ch2] + self.sine_freq[ch2]/10), "ch" + str(ch) + ": for samplerate " + str(samplerate) + " sine frequency " + str(freq) + " is higher then expected (" + str(self.sine_freq[ch2]) + ")")


	##### tests #####

	def setUp(self):
		common.load_modules()
		self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)

	def tearDown(self):
		common.remove_modules()

	@unittest.skipUnless(common.tfa_cnt_aec_profile, "no AEC container file profile specified")
	def test_audio_aec(self):
		# 1 AEC return channel for each input channel
		input_channels = self.info.get_nr_speakers()
		output_channels = 1 * input_channels
		print "AEC loopback test for " + str(output_channels) + " channel(s)"
		self.audio_loopback(common.tfa_cnt_aec_profile, input_channels, output_channels)

	@unittest.skipUnless(common.tfa_cnt_iv_profile, "no IV container file profile specified")
	def test_audio_iv(self):
		# 2 IV return channels for each input channel in 16 bit mode
		input_channels = self.info.get_nr_speakers()
		output_channels = 2 * input_channels
		print "IV loopback test for " + str(output_channels) + " channels"
		self.audio_loopback(common.tfa_cnt_iv_profile, input_channels, output_channels)

	@unittest.skipUnless(common.tfa_cnt_aec_profile, "no AEC container file profile specified")
	def test_audio_aec_2(self):
		# 1 AEC return channel for each input channel
		input_channels = self.info.get_nr_speakers()
		output_channels = 1 * input_channels

		# run test 2x to make test that audio does not only work the
		# first time after loading ther kernel modules
		print "AEC loopback test 1 for " + str(output_channels) + " channel(s)"
		self.audio_loopback(common.tfa_cnt_aec_profile, input_channels, output_channels)
		time.sleep(4)
		print "AEC loopback test 2 for " + str(output_channels) + " channel(s)"
		self.audio_loopback(common.tfa_cnt_aec_profile, input_channels, output_channels)

	@unittest.skipUnless(common.tfa_cnt_iv_profile, "no IV container file profile specified")
	def test_audio_iv_2(self):
		# 2 IV return channels for each input channel in 16 bit mode
		input_channels = self.info.get_nr_speakers()
		output_channels = 2 * input_channels

		# run test 2x to make test that audio does not only work the
		# first time after loading ther kernel modules
		print "IV loopback test 1 for " + str(output_channels) + " channels"
		self.audio_loopback(common.tfa_cnt_iv_profile, input_channels, output_channels)
		time.sleep(6)
		print "IV loopback test 2 for " + str(output_channels) + " channels"
		self.audio_loopback(common.tfa_cnt_iv_profile, input_channels, output_channels)

if __name__ == '__main__':
	unittest.main()

