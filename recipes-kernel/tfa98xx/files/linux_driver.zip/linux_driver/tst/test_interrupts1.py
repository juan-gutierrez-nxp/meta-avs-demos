import unittest

import common
import device_info
import audio_support
import climax_support
import gpio_support

# Tests interrupts from user space (using no_start kernel module option)
class TestInterrupts1(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)
	climax = climax_support.climax('/lib/firmware/'+ common.cnt_file)

	##### tests #####

	def setUp(self):
		common.load_modules(no_start=1)

	def tearDown(self):
		common.remove_modules()

	def test_interrupt_userspace(self):

		if self.info.tfa_family() == 1:
			print "no interrupts for TFA1 family"
			return

		# left:  irq-gpio = <&gpio1 28 GPIO_ACTIVE_LOW>;
		# right: irq-gpio = <&gpio0 30 GPIO_ACTIVE_LOW>;
		irq_gpios = [gpio_support.gpio(60), gpio_support.gpio(30)]

		if self.info.dsp_device():
			# minimum number channels on BBB is 2
			channels = 2
		else:
			# 2x I/V channels
			channels = 2 * self.info.get_nr_speakers()

		# start the audio clock by playing silence
		self.audio.start_silence_loop(48000, channels, 16, 300)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			# reset and start the amplifier
			self.climax.reset()
			self.climax.start()

			# make sure all interrupts are disabled
			self.climax.set_reg(0x48, 0)
			self.climax.set_reg(0x49, 0)
			self.climax.set_reg(0x4a, 0)

			# make sure all interrupts are cleared
			self.climax.set_reg(0x44, 0xffff)
			self.climax.set_reg(0x45, 0xffff)
			self.climax.set_reg(0x46, 0xffff)

			# enable NOCLK interrupt
			self.climax.set_bitfield("IENOCLK", 1)

			# check that NOCLK interrupt is not set
			noclk = self.climax.get_bitfield("ISTNOCLK")
			for name in self.info.device_names:
				self.assertEqual(int(noclk[name],0), 0, "NOCLK interrupt already set")

			# Check that no interrupts are fired
			for i in range(0, self.info.get_nr_devices()):
				irq = irq_gpios[i].read()
				self.assertEqual(irq, 1, "Interrupt line already fired")

		finally:
			# stop the audio clock
			self.audio.stop_silence_loop()

		# check that NOCLK interrupt is set
		noclk = self.climax.get_bitfield("ISTNOCLK")
		for name in self.info.device_names:
			self.assertEqual(int(noclk[name],0), 1, "NOCLK interrupt not set")

		# Check that interrupts are fired
		for i in range(0, self.info.get_nr_devices()):
			irq = irq_gpios[i].read()
			self.assertEqual(irq, 0, "Interrupt line not fired")



if __name__ == '__main__':
	unittest.main()

