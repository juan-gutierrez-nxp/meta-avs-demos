import os
import ConfigParser
from collections import OrderedDict
import climax_support

# http://stackoverflow.com/questions/15848674/how-to-configparse-a-file-keeping-multiple-values-for-identical-keys

class MultiOrderedDict(OrderedDict):
    def __setitem__(self, key, value):
        if isinstance(value, list) and key in self:
            self[key].extend(value)
        else:
            super(OrderedDict, self).__setitem__(key, value)

class device_info:

	climax = climax_support.climax('')

	samplerate_table = [8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000]

	stereo_devices = ["88"]
	probus_devices = ["72", "74"]
	tfa2_family_devices = stereo_devices + probus_devices + ["9912", "94"]

	# list with names of devices found in ini file
	device_names = []
	# i2c address for each [device_name]
	device_address = OrderedDict()
	# profiles for each [device_name]
	profiles = OrderedDict()
	# vsteps for each [profile]
	vsteps = OrderedDict()
	# samplerates for each [profile]
	samplerates = OrderedDict()

 	def __init__(self, inifile, tfa_device):

		self.tfa_device = tfa_device

		ini_path = os.path.dirname(inifile)

		config = ConfigParser.RawConfigParser(dict_type=MultiOrderedDict)
		config.read(inifile)

		self.device_names = config.get("system", "device")
		# application name is used as label for mixer
		self.application_name = config.get("system", "application")[0]

		all_profiles = list()
		for name in self.device_names:
			addr = config.get(name, "dev")
			self.device_address[name] = addr
			self.profiles[name] = config.get(name, "profile")

			# unique profiles from all devices
			all_profiles = list(set(all_profiles)|set(self.profiles[name]))

		self.mixer_profiles = OrderedDict()
		self.mixer_steps = OrderedDict()
		self.mixer_samplerates = OrderedDict()
		self.mixer_taptrigger = list()

		for profile in all_profiles:
			try:
				vstep = config.get(profile, "vstep")
				vstep_file = ini_path + "/" +vstep[0]
				if self.tfa_family() == 2:
					self.vsteps[profile] = self.climax.get_vsteps_tfa2(vstep_file)
				else:
					self.vsteps[profile] = self.climax.get_vsteps_tfa1(vstep_file)

			except ConfigParser.NoOptionError:
				# profile without vsteps
				self.vsteps[profile] = []

			try:
				# Note: the first AUDFS/I2SSR bitfield is the sample rate
				# of the profile. The second AUDFS/I2SSR is the one from
                                # the default section.
				if self.tfa_family() == 2:
					fs = int(config.get(profile, "AUDFS")[0])
				else:
					fs = int(config.get(profile, "I2SSR")[0])

			except ConfigParser.NoOptionError:
					fs = self.samplerate_table.index(48000)

			self.samplerates[profile] = self.samplerate_table[fs]

			# ignore calibration profile
			if profile.find(".cal") != -1:
				continue

			mixer_profile = profile.rsplit('.')[0]
			self.mixer_profiles.setdefault(mixer_profile, [])

			if profile not in self.mixer_profiles[mixer_profile]:
				self.mixer_profiles[mixer_profile].append(profile)
				self.mixer_steps[mixer_profile] = self.vsteps[profile]
				if ".tap" in profile:
					self.mixer_taptrigger.append(mixer_profile)

			self.mixer_samplerates.setdefault(mixer_profile, []).append(self.samplerate_table[fs])


	def mixer_to_profile(self, mixer_profile, samplerate=0):

		profiles = self.mixer_profiles[mixer_profile]
		profile = -1

		# mixer profile maps to only one container file profile
		if len(profiles) == 1:
			profile = profiles[0]
		# mixer profile maps to multiple container file profiles
		# assume multiple sample rates
		elif len(profiles) > 1:
			if samplerate > 0:
				if samplerate in self.mixer_samplerates[mixer_profile]:
					profile = mixer_profile + '.' + str(samplerate)

		return profile

	def tfa_family(self):
		if self.tfa_device in self.tfa2_family_devices:
			# TFA2 family
			return 2
		else:
			# TFA1 family
			return 1

	def stereo_device(self):
		return self.tfa_device in self.stereo_devices

	def dsp_device(self):
		return not self.tfa_device in self.probus_devices

	def get_nr_speakers(self):
		if self.stereo_device():
			# stereo device
			nr = 2
		else:
			# mono device
			nr = 1
		return nr * len(self.device_names)

	def get_nr_devices(self):
		return len(self.device_names)

