import unittest
import time

import common
import device_info
import audio_support
import climax_support
import gpio_support

# Tests interrupts from user space (using no_start kernel module option)
class TestReset(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)
	climax = climax_support.climax('/lib/firmware/'+ common.cnt_file)

	##### support functions #####

	# expectedFailureIf decorator (wrapper for unittest.expectedFailure)
	def expectedFailureIf(condition, reason):
		if not condition:
			return lambda func: func
		print "expectedFailure: " + reason
		return unittest.expectedFailure

	##### tests #####

	def setUp(self):
		common.load_modules(no_start=1, no_reset=1)

	def tearDown(self):
		common.remove_modules()

	@expectedFailureIf(common.tfa_device_id == "13", "9912/9892 reset problem: HW or board issue")
	def test_reset_userspace(self):

		if not self.info.dsp_device():
			# For devices without DSP, we can not check ACS
			print "Update test for devices without DSP"
			return

		nr_devices =  self.info.get_nr_devices()

		# Left:  reset-gpio = <&gpio1 17 GPIO_ACTIVE_LOW>;
		# right: reset-gpio = <&gpio0 31 GPIO_ACTIVE_LOW>;
		reset_gpios = [gpio_support.gpio(49), gpio_support.gpio(31)]

		# reset device(s)
		for i in range(0, nr_devices):
			reset_gpios[i].set_dir("out")
			reset_gpios[i].write(0)
			time.sleep(1)
			reset_gpios[i].write(1)
			time.sleep(1)
			reset_gpios[i].write(0)
			time.sleep(1)

		# check that the device is cold
		values = self.climax.get_bitfield("ACS")
		for name in self.info.device_names:
			self.assertEqual(int(values[name]), 1, "device is not cold")

		if self.info.dsp_device():
			# minimum number channels on BBB is 2
			channels = 2
		else:
			# 2x I/V channels
			channels = 2 * self.info.get_nr_speakers()

		# start the audio clock by playing silence
		self.audio.start_silence_loop(48000, channels, 16, 300)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			self.climax.start()
			time.sleep(6)
			self.climax.stop()

		finally:
			# stop the audio clock
			self.audio.stop_silence_loop()

		# check that the device is warm
		values = self.climax.get_bitfield("ACS")
		for name in self.info.device_names:
			self.assertEqual(int(values[name]), 0, "device is not warm")

		# reset device(s)
		for i in range(0, nr_devices):
			reset_gpios[i].write(1)
			time.sleep(1)
			reset_gpios[i].write(0)
			time.sleep(1)

		# check that the device is cold
		values = self.climax.get_bitfield("ACS")
		for name in self.info.device_names:
			self.assertEqual(int(values[name]), 1, "device is not cold after reset")

if __name__ == '__main__':
	unittest.main()
