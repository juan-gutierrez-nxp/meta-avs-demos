import unittest
import subprocess
import os

import common
import device_info
import tinyalsa_support
import audio_support

class TestAudioPCM(unittest.TestCase):

	tinyalsa = tinyalsa_support.tinyalsa()
	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)

	# parameters to be tested
	supported_channels = [2]
	unsupported_channels = [1]
	supported_sample_sizes = [16]
	unsupported_sample_sizes = [8, 24, 32]

	# default parameters used for testing
	default_channels = 2
	default_sample_rate = 48000
	default_sample_size = 16
	default_secs = 2

	@classmethod
	def setUpClass(cls):
		common.load_modules()

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### support functions #####

	def set_mixer_enum(self, name, value):
		return self.tinyalsa.mixer_ctl_set_enum(self.card_index, name, value)

	def get_mixer_enums(self, name):
		return self.tinyalsa.mixer_ctl_get_enums(self.card_index, name)

	def play_silence(self, samplerate=default_sample_rate, channels=default_channels, sample_size=default_sample_size):
		return self.audio.play_silence(samplerate, channels, sample_size, self.default_secs)

	def capture(self, samplerate=default_sample_rate, channels=default_channels, sample_size=default_sample_size):
		return self.audio.capture(samplerate, channels, sample_size, self.default_secs)

	##### tests #####

	def setUp(self):
		self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)

	def tearDown(self):
		pass

	def test_pcm_playback(self):
		ret = self.play_silence()
		self.assertEqual(ret, 0, "failed to playback")

	def test_pcm_playback_supported_channels(self):
		for channels in self.supported_channels:
			ret = self.play_silence(channels=channels)
			self.assertEqual(ret, 0, "failed to set nr of channels: " + str(channels))

	def test_pcm_playback_unsupported_channels(self):
		for channels in self.unsupported_channels:
			ret = self.play_silence(channels=channels)
			self.assertNotEqual(ret, 0, "able to set unsupported nr of channels: " + str(channels))

	def test_pcm_playback_supported_sample_sizes(self):
		for sample_size in self.supported_sample_sizes:
			ret = self.play_silence(sample_size=sample_size)
			self.assertEqual(ret, 0, "failed to set sample size: " + str(sample_size))

	def test_pcm_playback_unsupported_sample_sizes(self):
		for sample_size in self.unsupported_sample_sizes:
			ret = self.play_silence(sample_size=sample_size)
			self.assertNotEqual(ret, 0, "able to set unsupported sample size: " + str(sample_size))

	def test_pcm_capture(self):
		ret = self.capture()
		self.assertNotEqual(ret, "", "capture failed")

	def test_pcm_capture_supported_channels(self):
		for channels in self.supported_channels:
			ret = self.capture(channels=channels)
			self.assertNotEqual(ret, "", "failed to set nr of channels: " + str(channels))

	def test_pcm_capture_unsupported_channels(self):
		for channels in self.unsupported_channels:
			ret = self.capture(channels=channels)
			self.assertEqual(ret, "", "able to set unsupported nr of channels: " + str(channels))

	def test_pcm_capture_supported_sample_sizes(self):
		for sample_size in self.supported_sample_sizes:
			ret = self.capture(sample_size=sample_size)
			self.assertNotEqual(ret, "", "failed to set sample size: " + str(sample_size))

	def test_pcm_capture_unsupported_sample_sizes(self):
		for sample_size in self.unsupported_sample_sizes:
			ret = self.capture(sample_size=sample_size)
			self.assertEqual(ret, "", "able to set unsupported sample size: " + str(sample_size))

	def test_pcm_playback_test_samplerates(self):
		for name in self.info.device_names:
			# v1.x uses device names, v2.x uses application name
			mixer_label = self.info.application_name

			mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

			# check if mixer range matches number of volume steps
                        # for all profiles
			for mixer_profile in mixer_profiles:
				ret = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
				self.assertEqual(ret, 0, "error setting mixer value (" + str(ret) + ")")

				for samplerate in self.info.samplerate_table:
					ret = self.play_silence(samplerate=samplerate)
					if samplerate in self.info.mixer_samplerates[mixer_profile]:
						self.assertEqual(ret, 0, "failed to set sample rate: " + str(samplerate))
					else:
						self.assertNotEqual(ret, 0, "able to set unsupported sample rate: " + str(samplerate))


	def test_pcm_capture_test_samplerates(self):
		for name in self.info.device_names:
			# v1.x uses device names, v2.x uses application name
			mixer_label = self.info.application_name

			mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

			# check if mixer range matches number of volume steps
                        # for all profiles
			for mixer_profile in mixer_profiles:
				ret = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
				self.assertEqual(ret, 0, "error setting mixer value (" + str(ret) + ")")

				for samplerate in self.info.samplerate_table:
					ret = self.capture(samplerate=samplerate)
					if samplerate in self.info.mixer_samplerates[mixer_profile]:
						self.assertNotEqual(ret, "", "failed to set sample rate: " + str(samplerate))
					else:
						self.assertEqual(ret, "", "able to set unsupported sample rate: " + str(samplerate))


if __name__ == '__main__':
	unittest.main()

