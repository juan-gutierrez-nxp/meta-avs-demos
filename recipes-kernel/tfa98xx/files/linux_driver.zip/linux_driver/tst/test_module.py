import unittest
import subprocess
import os
import os.path
import time
import random

import common
import tinyalsa_support
import audio_support
from timeout_decorator import *

class TestModule(unittest.TestCase):

	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)
	tinyalsa = tinyalsa_support.tinyalsa()

	test_cnt_file_path = "tfa98/" + common.tfa_device + "/"
	firmware_path = "/lib/firmware/"

	##### support functions #####

	@timeout(5)
	def load_modules(self, cnt):
		try:
			ret = subprocess.call(["modprobe", common.tfa_module, "fw_name=" + cnt])
			self.assertEqual(ret, 0, "not able to load tfa98xx module")
			ret = subprocess.call(["modprobe", common.platform_module])
			self.assertEqual(ret, 0)
			ret = subprocess.call(["modprobe", common.soc_audio_module])
			self.assertEqual(ret, 0)

			time.sleep(1) # give the kernel some time

			# Check if the ALSA  codec probe was successfull
			audio_card_path = "/proc/asound/" + common.alsa_audiocard_name
			ret = os.path.exists(audio_card_path)
			self.assertTrue(ret, audio_card_path + " does not exist")

			self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)

		except TimedOutExc:
			self.fail("timeout loading modules")


	@timeout(5)
	def remove_modules(self):
		fnull = open(os.devnull, 'w')
		try:
			subprocess.call(["rmmod", common.platform_module], stdout=fnull, stderr=subprocess.STDOUT)
			subprocess.call(["rmmod", common.tfa_module], stdout=fnull, stderr=subprocess.STDOUT)
			subprocess.call(["rmmod", common.soc_audio_module], stdout=fnull, stderr=subprocess.STDOUT)
		except TimedOutExc:
			self.fail("timeout removing modules")
		fnull.close()

	def get_mixer_num_ctls(self):
		return self.tinyalsa.mixer_ctl_get_num_ctls(self.card_index)

	##### tests #####

	def setUp(self):
		# make sure modules are removed
		self.remove_modules()

	def tearDown(self):
		time.sleep(2) # give the kernel some time
		self.remove_modules()

	def test_tfa_module_loaded(self):
		self.load_modules(common.cnt_file)
		# check if the i2c probe was successfull
		for driver_name in common.driver_names:
			ret = os.path.exists("/sys/bus/i2c/drivers/" + driver_name)
			if ret == True:
				break
		self.assertTrue(ret, "tfa98xx driver not loaded")

	def test_modules_loaded(self):
		self.load_modules(common.cnt_file)
		# check that mixer controls have been created
		self.assertTrue(self.get_mixer_num_ctls() > 0, "Error loading valid container file" )

	def test_not_existing_cnt(self):
		self.load_modules("not_existing.cnt")
		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading not excisting file")

	def test_cnt_empty(self):
		# Create empty container file
		test_cnt_file = self.test_cnt_file_path + "test_empty.cnt"
		open(self.firmware_path + test_cnt_file, 'wb').close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading empty container file")

	def test_cnt_zeros(self):
		# Create container file of length 3280 with only zeros
		test_cnt_file = self.test_cnt_file_path + "test_zeros.cnt"
		out = open(self.firmware_path + test_cnt_file, 'wb')
		for _ in range(3280):
			out.write('%c' % 0)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with zeros")

	def test_cnt_version(self):
		test_cnt_file = self.test_cnt_file_path + "test_version.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# clear version and subversion of container file
		data[2] = 0
		data[3] = 0
		data[4] = 0
		data[5] = 0

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with wrong versions")

	def test_cnt_data_size_larger(self):
		test_cnt_file = self.test_cnt_file_path + "test_data_size_larger.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# modify the size field
		data[7] = data[7] + 1

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with wrong data size field")

	def test_cnt_data_size_smaller(self):
		test_cnt_file = self.test_cnt_file_path + "test_data_size_smaller.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# modify the size field
		data[7] = data[7] - 1

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with wrong data size field")

	def test_cnt_data_size_null(self):
		test_cnt_file = self.test_cnt_file_path + "test_data_size_null.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# make data size 0
		data[6] = 0
		data[7] = 0

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with wrong data size field")

	def test_cnt_data_crc(self):
		test_cnt_file = self.test_cnt_file_path + "test_crc.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# modify one of the bytes of the CRC field
		data[8] = data[8] + 1

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with wrong crc")

	def test_cnt_corrupt_data(self):
		test_cnt_file = self.test_cnt_file_path + "test_corrupt_data.cnt"
		input_cnt_file = self.firmware_path + common.cnt_file

		inp = open(input_cnt_file, 'rb')
		data = bytearray(inp.read())
		inp.close()

		# introduce error in the data at a random position
		data_offset = 36
		file_size = os.path.getsize(input_cnt_file)
		position = random.randint(data_offset, file_size-1)
		data[position] = 255 - data[position]

		out = open(self.firmware_path + test_cnt_file, 'wb')
		out.write(data)
		out.close()

		# load module
		self.load_modules(test_cnt_file)

		# cleanup
		os.remove(self.firmware_path + test_cnt_file)

		# check that no mixer controls have been created
		self.assertFalse(self.get_mixer_num_ctls() > 0, "Error loading container file with corrupt data")

	def test_playback_without_cnt(self):
		self.load_modules("invalid.cnt")

		# Test that playing audio without a valid container file fails
		ret = self.audio.play_silence(48000, 2, 16, 1)
		self.assertNotEqual(ret, 0, "Playback should return an error")

	def test_capture_without_cnt(self):
		self.load_modules("invalid.cnt")

		# Test that capturing audio without a valid container file fails
		ret = self.audio.capture(48000, 2, 16, 1)
		self.assertEqual(ret, "", "Capture should return an error")

if __name__ == '__main__':
	unittest.main()

