import unittest
import evdev

import common
import device_info

class TestInputDevice(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)

	@classmethod
	def setUpClass(cls):
		common.load_modules()

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### support functions #####

	# sanity checks, to make sure that device_info is available
	def check_device_info(self):
		if not self.info.device_names:
			self.fail("no devices found in ini file")
		if not self.info.profiles:
			self.fail("no profiles found in ini file")

	##### tests #####

	def setUp(self):
		self.check_device_info()

	def tearDown(self):
		pass

	# Test if input device is available when a taptrigger profile is specified
	def test_input_device_available(self):
		for mixer_profile in self.info.mixer_profiles:
			if mixer_profile in self.info.mixer_taptrigger:
				found = False
				for device in evdev.list_devices():
					found = evdev.InputDevice(device).name == "tfa98xx-tapdetect"
					if found:
						break
				self.assertTrue(found, "tap trigger profile found, but no input device available")


