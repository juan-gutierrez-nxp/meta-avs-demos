import unittest

import common
import device_info
import tinyalsa_support
import climax_support

class TestAudioMixer(unittest.TestCase):

	tinyalsa = tinyalsa_support.tinyalsa()
	climax = climax_support.climax('/lib/firmware/'+ common.cnt_file)
	info = device_info.device_info(common.ini_file, common.tfa_device)

	@classmethod
	def setUpClass(cls):
		common.load_modules()

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### support functions #####

	def set_mixer_enum(self, name, value):
		return self.tinyalsa.mixer_ctl_set_enum(self.card_index, name, value)

	def get_mixer_enums(self, name):
		return self.tinyalsa.mixer_ctl_get_enums(self.card_index, name)

	def set_mixer_value(self, name, value):
		return self.tinyalsa.mixer_ctl_set_value(self.card_index, name, value)

	def get_mixer_value(self, name):
		return self.tinyalsa.mixer_ctl_get_value(self.card_index, name)

	def get_mixer_min(self, name):
		return self.tinyalsa.mixer_ctl_get_range_min(self.card_index, name)

	def get_mixer_max(self, name):
		return self.tinyalsa.mixer_ctl_get_range_max(self.card_index, name)

	def set_mixer_values(self, name, values):
		return self.tinyalsa.mixer_ctl_set_values(self.card_index, name, values)

	def get_mixer_values(self, name):
		return self.tinyalsa.mixer_ctl_get_values(self.card_index, name)

	# sanity checks, to make sure that device_info is available
	def check_device_info(self):
		if not self.info.device_names:
			self.fail("no devices found in ini file")
		if not self.info.profiles:
			self.fail("no profiles found in ini file")
		if not self.info.vsteps:
			self.fail("no vsteps found in ini file")

	##### tests #####

	def setUp(self):
		self.card_index = self.tinyalsa.cardname_to_index(common.alsa_audiocard_name)
		self.check_device_info()

	def tearDown(self):
		pass

	# test max length of mixer control name
	def test_mixer_ctl_name_lenth(self):

		maxlen = self.tinyalsa.maxlen_ctl_name()

		for name in self.info.device_names:
			# v1.x uses device names, v2.x uses application name
			mixer_label = self.info.application_name

			profile_ctl = mixer_label + " Profile"
			self.assertTrue(len(profile_ctl) <= maxlen, "name " + profile_ctl + " is too long")

			for profile in self.info.profiles[name]:
				# Skip profiles without vsteps
				if len(self.info.vsteps[profile]) > 0:
					volume_ctl = mixer_label + " " + profile + " Playback Volume"
					self.assertTrue(len(volume_ctl) <= maxlen, "name " + volume_ctl + " is too long")

	# Tests setting all the profiles/volume and checks the volume against the number of vsteps
	def test_mixer_ctl_profiles_vsteps(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		# check if mixer range matches number of volume steps
		# for all profiles
		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"

				min_vol = self.get_mixer_min(volume_ctl)
				max_vol = self.get_mixer_max(volume_ctl)

				self.assertTrue(min_vol>=0, "Profile " + mixer_profile + ": min volume (" + str(min_vol) +") incorrect")
				self.assertTrue(max_vol>=0, "Profile " + mixer_profile + ": max volume (" + str(max_vol) +") incorrect")

				steps = max_vol - min_vol + 1
				self.assertEqual(steps, len(self.info.mixer_steps[mixer_profile]), volume_ctl + ": number of vsteps does not match container file")

	# Tests setting the volume for all profiles
	def test_mixer_ctl_set_volume(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				min_vol = self.get_mixer_min(volume_ctl)
				max_vol = self.get_mixer_max(volume_ctl)

				# set all volume level in range
				for vol1 in range(min_vol, max_vol+1):
					vols1 = [vol1] * self.info.get_nr_devices()
					self.set_mixer_values(volume_ctl, vols1)
					self.assertEqual(err, 0, "error setting " + volume_ctl + " (" + str(err) + ")")
					vols2 = self.get_mixer_values(volume_ctl)
					self.assertEqual(vols1, vols2, volume_ctl + ": volume "+ str(vol1) + " could not be set")

	# Tests setting an invalid volume for all profiles (max + 1)
	def test_mixer_ctl_set_volume_invalid1(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				max_vol = self.get_mixer_max(volume_ctl)

				# set volume to more then max
				vol1 = max_vol + 1
				vols1 = [vol1] * self.info.get_nr_devices()
				err = self.set_mixer_values(volume_ctl, vols1)
				self.assertNotEqual(err, 0, volume_ctl + " (" + str(err) + ") more then max")
				vols2 = self.get_mixer_values(volume_ctl)
				self.assertNotEqual(vols1, vols2, volume_ctl + ": volume "+ str(vol1) + " could be set")

	# Tests setting an invalid volume for all profiles (min - 1)
	def test_mixer_ctl_set_volume_invalid2(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				min_vol = self.get_mixer_min(volume_ctl)

				# set volume to less then min
				vol1 = min_vol - 1
				vols1 = [vol1] * self.info.get_nr_devices()
				err = self.set_mixer_values(volume_ctl, vols1)
				self.assertNotEqual(err, 0, volume_ctl + " (" + str(err) + ") less then min")
				vols2 = self.get_mixer_values(volume_ctl)
				self.assertNotEqual(vols1, vols2, volume_ctl + ": volume "+ str(vol1) + " could be set")

	# Tests if all mixer profiles and ini/cnt file are the same
	def test_mixer_ctl_profiles(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		# check if mixer control profiles are in container file
		for mixer_profile in mixer_profiles:
			self.assertTrue(mixer_profile in self.info.mixer_profiles, mixer_label + " Profile: profile " + mixer_profile + " not in container file")

		# check if container file  profiles are in mixer control
		for mixer_profile in self.info.mixer_profiles:
			self.assertTrue(mixer_profile in mixer_profiles, mixer_label + " Profile: profile " + mixer_profile + " not in mixer control")

	# Test setting an invalid profile (max profile + 1)
	def test_mixer_ctl_invalid_profile1(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")
		nr_mixer_profiles = len(mixer_profiles)

		# get original value
		original_value = self.get_mixer_value(mixer_label + " Profile")
		self.assertFalse(original_value < 0, "error reading mixer value (" + str(original_value) + ")")

		# set profile enum which is out of range
		invalid_profile = nr_mixer_profiles # max profile + 1
		err = self.set_mixer_value(mixer_label + " Profile", invalid_profile)
		self.assertTrue(err < 0, "error, possible to set invalid profile")

		# check that the value has not changed
		value = self.get_mixer_value(mixer_label + " Profile")
		self.assertFalse(value < 0, "error reading mixer value (" + str(value) + ")")
		self.assertEqual(original_value , value, "error setting invalid profile succeeded")

	# Test setting an invalid profile (min profile - 1)
	def test_mixer_ctl_invalid_profile2(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")
		nr_mixer_profiles = len(mixer_profiles)

		# get original value
		original_value = self.get_mixer_value(mixer_label + " Profile")
		self.assertFalse(original_value < 0, "error reading mixer value (" + str(original_value) + ")")

		# set profile enum which is out of range
		invalid_profile = -1 # min profile - 1
		err = self.set_mixer_value(mixer_label + " Profile", invalid_profile)
		self.assertTrue(err < 0, "error, possible to set invalid profile")

		# check that the value has not changed
		value = self.get_mixer_value(mixer_label + " Profile")
		self.assertFalse(value < 0, "error reading mixer value (" + str(value) + ")")
		self.assertEqual(original_value , value, "error setting invalid profile succeeded")

	# Tests if setting the colume for one profile does not change the volume of another profile
	def test_mixer_ctl_set_volume2(self):
		mixer_label = self.info.application_name
		mixer_profiles = self.get_mixer_enums(mixer_label + " Profile")

		# set all volumes to min
		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				min_vol = self.get_mixer_min(volume_ctl)
				min_vols = [min_vol] * self.info.get_nr_devices()
				self.set_mixer_values(volume_ctl, min_vols)
				self.assertEqual(err, 0, "error setting " + volume_ctl + " (" + str(err) + ")")

		first = False
		for mixer_profile in mixer_profiles:
			err = self.set_mixer_enum(mixer_label + " Profile", mixer_profile)
			self.assertEqual(err, 0, "error setting mixer value (" + str(err) + ")")

			# Skip profiles without vsteps
			if len(self.info.mixer_steps[mixer_profile]) > 0:
				volume_ctl = mixer_label + " " + mixer_profile + " Playback Volume"
				min_vol = self.get_mixer_min(volume_ctl)
				max_vol = self.get_mixer_max(volume_ctl)

				if not first:
					first = True

					# Set first profile volume to max
					max_vols = [max_vol] * self.info.get_nr_devices()
					self.set_mixer_values(volume_ctl, max_vols)
					self.assertEqual(err, 0, "error setting " + volume_ctl + " (" + str(err) + ")")

					vols1 = self.get_mixer_values(volume_ctl)
					self.assertEqual(vols1, max_vols, volume_ctl + ": volume "+ str(vols1) + " could not be set")
				else:
					# Check other profiles are not changed
					min_vols = [min_vol] * self.info.get_nr_devices()
					vols1 = self.get_mixer_values(volume_ctl)
					self.assertEqual(vols1, min_vols, volume_ctl + ": volume "+ str(vols1) + " could not be set")

	# Test if Stop mixer control excists for TFA1 devices
	def test_mixer_ctl_stop(self):
		mixer_label = self.info.application_name
		stop_ctl = mixer_label + " Stop"

		values0 = [0] * self.info.get_nr_devices()
		err = self.set_mixer_values(stop_ctl, values0)
		self.assertEqual(err, 0, "error setting " + stop_ctl + " (" + str(err) + ")")

		values = self.get_mixer_values(stop_ctl)
		self.assertEqual(values0, values, "Error getting value of " + stop_ctl)

		values1 = [1] * self.info.get_nr_devices()
		err = self.set_mixer_values(stop_ctl, values1)
		self.assertEqual(err, 0, "error setting " + stop_ctl + " (" + str(err) + ")")

		values = self.get_mixer_values(stop_ctl)
		self.assertEqual(values0, values, "Error getting value of " + stop_ctl)

	# Test if calibration control excists for 72 devices
	def test_mixer_ctl_calibrate(self):
		nr_devices = self.info.get_nr_devices()
		mixer_label = self.info.application_name
		cal_ctl = mixer_label + " Calibration"
		values = self.get_mixer_values(cal_ctl)
		if self.info.tfa_device == "72":
			print "calibration: " + str(values)
			self.assertEqual(len(values), nr_devices, cal_ctl + ": Error getting calibration value")
		else:
			self.assertFalse(len(values) > 0, cal_ctl + ": Error should not get calibration value")

if __name__ == '__main__':
	unittest.main()

