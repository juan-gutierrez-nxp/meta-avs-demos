platform_module  = "snd-soc-bbb-nxp-tfa"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

tfa_device = "97"
tfa_device_id = tfa_device
alsa_audiocard_name = "TFA9891" # nxp,model in dts file

tfa_cnt_basename = "mono_bbb"
tfa_cnt_aec_profile="HQ_aec"
tfa_cnt_iv_profile=""

