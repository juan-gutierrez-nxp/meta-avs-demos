import subprocess
import time

from timeout_decorator import *
from tfa_config import *


# ini file used for creating the container file
ini_file = tfa_device + "/" + tfa_cnt_basename + ".ini"

# container file relative to /lib/firmware/
cnt_file = "tfa98/" + tfa_device + "/" + tfa_cnt_basename + ".cnt"

# driver names which can be specified in the device tree
driver_names = ["tfa98xx", "tfa9872", "tfa9874", "tfa9888", "tfa9890", "tfa9891", "tfa9894", "tfa9895", "tfa9896", "tfa9897", "tfa9912"]

@timeout(6)
def load_modules(no_start=0, no_reset=0, cnt=cnt_file, trace_lvl=1):
	ret = 1
	try:
		ret = subprocess.call(["modprobe", tfa_module, "fw_name=" + cnt, "trace_level=" + str(trace_lvl), \
		                                   "no_start=" + str(no_start), "no_reset=" + str(no_reset)])
		if ret != 0:
			print "Error loading module " + tfa_module
			return ret
		ret = subprocess.call(["modprobe", platform_module])
		if ret != 0:
			print "Error loading module " + platform_module
			return ret
		ret = subprocess.call(["modprobe", soc_audio_module])
		if ret != 0:
			print "Error loading module " + soc_audio_module
			return ret
	except TimedOutExc:
		print "timeout loading modules"

	time.sleep(2) # give the kernel some time
	return ret

@timeout(5)
def remove_modules():
	time.sleep(1) # give the kernel some time
	ret = 1
	try:
		ret = subprocess.call(["rmmod", platform_module])
		if ret != 0:
			print "Error removing module " + platform_module
			return ret
		ret = subprocess.call(["rmmod", soc_audio_module])
		if ret != 0:
			print "Error removing module " + soc_audio_module
			return ret
		ret = subprocess.call(["rmmod", tfa_module])
		if ret != 0:
			print "Error removing module " + tfa_module
			return ret
	except TimedOutExc:
		print "timeout removing modules"

	time.sleep(1) # give the kernel some time
	return ret

