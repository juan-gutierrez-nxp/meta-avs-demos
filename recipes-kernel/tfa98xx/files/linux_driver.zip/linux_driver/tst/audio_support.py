import math
import alsaaudio
import threading

class audio:

	def __init__(self, card):
		self.card = card

	__map_size_pcm_format = {
		 8: alsaaudio.PCM_FORMAT_U8,
		16: alsaaudio.PCM_FORMAT_S16_LE,
		24: alsaaudio.PCM_FORMAT_S24_LE,
		32: alsaaudio.PCM_FORMAT_S32_LE
	}

	def __sample_format(self, size):
		if size in self.__map_size_pcm_format:
			return 	self.__map_size_pcm_format[size]
		return -1

	def __sample_bits(self, size):
		return size

	def play_silence(self, fs, channels, size, secs):
		silence = "\0" * (self.__sample_bits(size) / 8) * channels * secs * fs
		return self.play(silence, fs, channels, size, secs)

	def play(self, data, fs, channels, size, secs):
		period_size = 512

		fmt = self.__sample_format(size)
		if fmt < 0:
			print "Invalid playback format " + str(size)
			return -1

		try:
			out = alsaaudio.PCM(type=alsaaudio.PCM_PLAYBACK, mode=alsaaudio.PCM_NORMAL, device=self.card)
		except:
			print "Error opening PCM device: " + self.card
			return -1

		fmt2 = out.setformat(fmt)
		if fmt != fmt2:
			print "Can not set playback format to " + str(fmt)
			return -1

		channels2 = out.setchannels(channels)
		if channels != channels2:
			print "Can not set playback channels to " + str(channels)
			return -1

		fs2 = out.setrate(fs)
		if fs != fs2:
			print "Can not set sample rate to " + str(fs)
			return -1

		period_size2 = out.setperiodsize(period_size)
		if period_size != period_size2:
			print "Can not set playback period size to " + str(period_size)
			return -1

		l = out.write(data)
		if  l < 0:
			print "Error writing audio to device"
			return -1

		out.close()
		return 0

	def __play_silence_loop(self, fs, channels, size, timeout_secs):
		period_size = 512
		nr_periods = 8

		fmt = self.__sample_format(size)
		assert fmt >= 0, "Invalid playback format " + str(size)

		out = alsaaudio.PCM(type=alsaaudio.PCM_PLAYBACK, mode=alsaaudio.PCM_NORMAL, device=self.card)

		fmt2 = out.setformat(fmt)
		assert fmt == fmt2, "Can not set playback format to " + str(fmt)

		channels2 = out.setchannels(channels)
		assert channels == channels2, "Can not set channels to " + str(channels)

		fs2 = out.setrate(fs)
		assert fs == fs2, "Can not set sample rate " + str(fs)

		period_size2 = out.setperiodsize(period_size)
		assert period_size == period_size2, "Can not set playback period size to " + str(period_size)

		nr_frames = period_size * nr_periods
		max_loops = math.ceil(timeout_secs * fs / nr_frames)
		silence = "\0" * (self.__sample_bits(size) / 8) * channels * nr_frames

		loops = 0
		while ((self.stop_loop == False) and (loops < max_loops)):
			l = out.write(silence)
			assert l > 0, "Error writing audio to device"
			loops += 1

		out.close()

		assert loops < max_loops, "timeout in __play_silence_loop()"

	def start_silence_loop(self, fs, channels, size, timeout_secs):
		self.t = threading.Thread(target=self.__play_silence_loop, name="__play_silence_loop", args=(fs, channels, size, timeout_secs))
		self.stop_loop = False
		self.t.start()

	def stop_silence_loop(self):
		self.stop_loop = True
		self.t.join()

	def capture(self, fs, channels, size, secs):
		period_size = 512

		fmt = self.__sample_format(size)
		if fmt < 0:
			print "Invalid capture format " + str(size)
			return ""

		try:
			inp = alsaaudio.PCM(type=alsaaudio.PCM_CAPTURE, mode=alsaaudio.PCM_NORMAL, device=self.card)
		except:
			print "Error opening PCM device: " + self.card
			return ""

		fmt2 = inp.setformat(fmt)
		if fmt != fmt2:
			print "Can not set capture format to " +str(fmt)
			return ""

		channels2 = inp.setchannels(channels)
		if channels != channels2:
			print "Can not set " + str(channels) + " capture channel(s)"
			return ""

		fs2 = inp.setrate(fs)
		if fs != fs2:
			print "Can not set capture sample rate to " + str(fs)
			return ""

		period_size2 = inp.setperiodsize(period_size)
		if period_size != period_size2:
			print "Can not set capture period size to " + str(period_size)
			return ""

		nr_frames = fs * secs
		nr_periods = int(math.ceil(nr_frames / period_size))

		data2 = ""
		for i in range(nr_periods + 1):
			l, data = inp.read()
			if l < 0:
				print "Error reading audio from device"
				return ""
			data2 += data

		inp.close()

		return data2

