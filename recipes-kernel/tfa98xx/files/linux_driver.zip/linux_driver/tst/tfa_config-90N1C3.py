platform_module  = "snd-soc-bbb-nxp-tfa"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

tfa_device = "90"
tfa_device_id = "80"
alsa_audiocard_name = "TFA9891" # nxp,model in dts file

#tfa_cnt_basename = "mono"
tfa_cnt_basename = "stereo"

