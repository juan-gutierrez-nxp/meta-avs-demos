import unittest

import common
import device_info
import audio_support

class TestNoStartModuleOption(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)

	# default parameters used for testing
	default_channels = 2
	default_sample_rate = 48000
	default_sample_size = 16
	default_secs = 4

	@classmethod
	def setUpClass(cls):
		common.load_modules(no_start=1)

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### tests #####

	def setUp(self):
		pass

	def tearDown(self):
		pass

	# test PCM playback
	def test_no_start_playback(self):
		ret = self.audio.play_silence(self.default_sample_rate, self.default_channels, self.default_sample_size, self.default_secs)
		self.assertEqual(ret, 0, "Playback error")

	# test PCM capture
	def test_no_start_capture(self):
		ret = self.audio.capture(self.default_sample_rate, self.default_channels, self.default_sample_size, self.default_secs)
		self.assertNotEqual(ret, "", "Capture error")

if __name__ == '__main__':
	unittest.main()

