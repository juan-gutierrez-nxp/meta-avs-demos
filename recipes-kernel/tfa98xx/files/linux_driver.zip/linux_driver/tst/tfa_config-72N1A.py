platform_module  = "snd-soc-bbb-nxp-tfa"
soc_audio_module = "snd-soc-davinci-mcasp"
tfa_module       = "snd-soc-tfa98xx"

alsa_audiocard_name = "TFA9872"

tfa_device = "72"
tfa_device_id = tfa_device
tfa_cnt_basename = "mono_no_dsp_bbb"
tfa_cnt_aec_profile=""
tfa_cnt_iv_profile="music"

