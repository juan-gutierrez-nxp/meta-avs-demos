import numpy as np

def zeroCrossingRate(data):
	signs = np.sign(data)
	signs[signs == 0] = -1
	return 1.0 * len(np.where(np.diff(signs))[0])/len(data)

def detect_sine_frequency(audio, fs):
	t = len(audio) / fs
	return fs * zeroCrossingRate(audio) / 2

