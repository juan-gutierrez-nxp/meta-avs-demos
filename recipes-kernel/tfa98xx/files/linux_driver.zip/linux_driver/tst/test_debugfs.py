import unittest
import os
import os.path
import time
import re
import errno

import common
import device_info
import audio_support

# Skip calibrations tests to avoid MTP wear out
skip_calibration_tests = True


class TestDebugfs(unittest.TestCase):

	info = device_info.device_info(common.ini_file, common.tfa_device)
	audio = audio_support.audio("hw:"+common.alsa_audiocard_name)

	##### support functions #####

	def get_debugfs_path(self, name):
		addr = self.info.device_address[name][0][2:]
		for driver_name in common.driver_names:
			path = "/sys/kernel/debug/" + driver_name + "-" + addr + "/"
			ret = os.path.exists(path)
			if ret == True:
				return path
		return None

	def write_debugfs(self, name, entry, value_str):
		path = self.get_debugfs_path(name) + entry
		fd = open(path, "w")
		fd.write(value_str)
		fd.close()

	def read_debugfs(self, name, entry):
		path = self.get_debugfs_path(name) + entry
		fd = open(path, "r")
		value_str = fd.read().replace("\n", "").rstrip('\0')
		fd.close()
		return value_str

	def parse_calibration_values(self, s):
		return re.findall('\d+', s)

	def is_number(self, s):
		try:
			float(s)
			return True
		except ValueError:
			pass
		return False

	##### tests #####

	@classmethod
	def setUpClass(cls):
		common.load_modules()

	@classmethod
	def tearDownClass(cls):
		common.remove_modules()

	##### tests #####

	def setUp(self):
		pass

	def tearDown(self):
		pass

	def test_debugfs_supported(self):
		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			print "debugfs path: " + str(path)
			self.assertNotEqual(path, None, "no debugfs support")

	def test_debugfs_version(self):
		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "version"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no version support in debugfs")
			fd = open(path, "r")
			version = fd.read().replace("\n", "")
			fd.close()
			print "version: " + version.rstrip('\0')
			self.assertFalse(len(version) < len("v0.0.0"), "Error in version number, version = " + version)

	def test_debugfs_fw_state(self):
		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "fw-state"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no fw-state support in debugfs")
			fd = open(path, "r")
			fw_state = fd.read().replace("\n", "")
			fd.close()
			self.assertEqual(fw_state, "Ok", "container file not loaded correctly, fw-state = " + fw_state)

	def test_debugfs_dsp_state_stopped(self):
		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "dsp-state"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no dsp-state support in debugfs")
			fd = open(path, "r")
			dsp_state = fd.read().replace("\n", "")
			fd.close()
			self.assertEqual(dsp_state, "Stopped", "device is running without audio, dsp-state = " + dsp_state)

	def test_debugfs_dsp_state_running(self):

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "dsp-state"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no dsp-state support in debugfs")

				fd = open(path, "r")
				dsp_state = fd.read().replace("\n", "")
				fd.close()
				self.assertEqual(dsp_state, "Init complete", "device is not running, dsp-state = " + dsp_state)

		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_rpc(self):
		if not self.info.dsp_device():
			print "debugfs rpc requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "rpc"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no rpc support in debugfs")

				rpc = open(path, "r+b", 0)
				msg = bytearray([0x00, 0x80, 0xFF])
				rpc.write(msg)
				data = rpc.read(138)
				rpc.close()

				# convert to string
				result = ""
				for byte in data:
					if byte != '\x00':
						result += byte
					if byte == '>':
						break
				print result

				if self.info.tfa_family() == 2:
					check_substr = "App_Max2"
				else:
					check_substr = "App_Demo_Maximus"

				self.assertTrue(check_substr in result, "not a correct romid tag")

		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_rpc_invalid_msg(self):
		if not self.info.dsp_device():
			print "debugfs rpc requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "rpc"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no rpc support in debugfs")

				rpc = open(path, "r+b", 0)
				msg = bytearray([0x00, 0x00, 0x00])

				err = 0
				try:
					rpc.write(msg) # fails with I/O Error
					rpc.close()
				except IOError, e:
					err = e.errno
				except:
					raise
				self.assertEqual(err, errno.EIO, "Writing invalid DSP message should have failed")
		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_rpc_noclk(self):
		if not self.info.dsp_device():
			print "debugfs rpc requires a DSP"
			return

		# make sure the clock has stopped
		time.sleep(1)

		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "rpc"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no rpc support in debugfs")

			rpc = open(path, "r+b", 0)
			msg = bytearray([0x00, 0x80, 0xFF])

			err = 0
			try:
				rpc.write(msg) # fails with I/O Error
				rpc.close()
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EIO, "Writing DSP message without clock should have failed")

	def test_debugfs_r(self):
		if not self.info.dsp_device():
			print "debugfs R requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "R"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no R support in debugfs")
				fd = open(path, "r")
				R = fd.read().replace("\n", "").rstrip('\0')
				fd.close()
				print "R: " + R
				cal = self.parse_calibration_values(R)
				nr_speakers = 1 + int(self.info.stereo_device())
				self.assertEqual(nr_speakers, len(cal), "number of speakers does not match the number R values")
				for r in cal:
					self.assertTrue(int(r) > 0, "R value is 0")

		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_otc_read(self):
		if not self.info.dsp_device():
			print "debugfs OTC requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "OTC"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no OTC support in debugfs")
				fd = open(path, "r")
				otc = fd.read().replace("\n", "").rstrip('\0')
				fd.close()
				print "OTC: " + otc
				self.assertTrue((int(otc) == 0) or (int(otc) == 1), "invalid value for OTC")

		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_otc_write_invalid(self):
		if not self.info.dsp_device():
			print "debugfs OTC requires a DSP"
			return

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "OTC", "2") # fails with Invalid argument
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EINVAL, "writing value othern 0 or 1 to OTC should have failed")

	def test_debugfs_otc_write_noclk(self):
		if not self.info.dsp_device():
			print "debugfs OTC requires a DSP"
			return

		# make sure the clock has stopped
		time.sleep(1)

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "OTC", "1") # fails with Input/output error
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EIO, "writing value to OTC without clock should have failed")

	def test_debugfs_mtpex_read(self):
		if not self.info.dsp_device():
			print "debugfs MTPEX requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:
				path = self.get_debugfs_path(name)
				self.assertNotEqual(path, None, "no debugfs support")
				path = path + "MTPEX"
				ret = os.path.exists(path)
				self.assertTrue(ret, "no MTPEX support in debugfs")
				fd = open(path, "r")
				mtpex = fd.read().replace("\n", "").rstrip('\0')
				fd.close()
				print "MTPEX: " + mtpex
				self.assertTrue((int(mtpex) == 0) or (int(mtpex) == 1), "Error invalid value for MTPEX")

		finally:
			self.audio.stop_silence_loop()

	def test_debugfs_mtpex_write_invalid(self):
		if not self.info.dsp_device():
			print "debugfs MTPEX requires a DSP"
			return

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "MTPEX", "1") # fails with Invalid argument
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EINVAL, "writing value other then 0 to MTPEX should have failed")

	def test_debugfs_mtpex_write_noclk(self):
		if not self.info.dsp_device():
			print "debugfs MTPEX requires a DSP"
			return

		# make sure the clock has stopped
		time.sleep(1)

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "MTPEX", "0") # fails with Input/output error
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EIO, "writing value to MTPEX without clock should have failed")

	def test_debugfs_temp_read(self):
		if not self.info.dsp_device():
			print "debugfs TEMP requires a DSP"
			return

		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "TEMP"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no TEMP support in debugfs")
			fd = open(path, "r")
			temp = fd.read().replace("\n", "").rstrip('\0')
			fd.close()
			print "TEMP: " + temp
			self.assertTrue(self.is_number(temp), "Error TEMP is not a number")

	def test_debugfs_calibrate_read(self):
		if not self.info.dsp_device():
			print "debugfs calibration requires a DSP"
			return

		for name in self.info.device_names:
			path = self.get_debugfs_path(name)
			self.assertNotEqual(path, None, "no debugfs support")
			path = path + "calibrate"
			ret = os.path.exists(path)
			self.assertTrue(ret, "no calibrate support in debugfs")

			fd = open(path, "r")
			err = 0
			try:
				fd.read() # fails with Invalid argument
				fd.close()
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EINVAL, "reading calibrate should have failed")

	def test_debugfs_calibrate_write_invalid(self):
		if not self.info.dsp_device():
			print "debugfs calibration requires a DSP"
			return

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "calibrate", "incorrect string") # fails with Invalid argument
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EINVAL, "writing invalid calibration string should have failed")

	def test_debugfs_mtpex_calibrate_noclk(self):
		if not self.info.dsp_device():
			print "debugfs calibrate requires a DSP"
			return

		# make sure the clock has stopped
		time.sleep(1)

		for name in self.info.device_names:
			err = 0
			try:
				self.write_debugfs(name, "calibrate", "please calibrate now") # fails with Input/output error
			except IOError, e:
				err = e.errno
			except:
				raise
			self.assertEqual(err, errno.EIO, "writing value to calibrate without clock should have failed")

	@unittest.skipIf(skip_calibration_tests, "skip test to avoid MTP wear out")
	def test_debugfs_calibrate_always(self):
		if not self.info.dsp_device():
			print "debugfs calibration requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:

				# read old calibration value(s)
				R = self.read_debugfs(name, "R")
				cal1 = self.parse_calibration_values(R)

				# initiate calibration
				self.write_debugfs(name, "MTPEX", "0")
				self.write_debugfs(name, "OTC", "0")
				self.write_debugfs(name, "calibrate", "please calibrate now")

				# give the device some time to do calibration
				time.sleep(5)

				# read new calibration value(s)
				R = self.read_debugfs(name, "R")
				cal2 = self.parse_calibration_values(R)

				# check calibration value(s) has/have changed
				for value1, value2 in zip(cal1, cal2):
					self.assertNotEqual(value1, value2, name + ": calibration value not changed")

				# check that MTPEX is not set
				mtpex = int(self.read_debugfs(name, "MTPEX"))
				self.assertEqual(mtpex, 0, name + ": MPTEX is not 0")

				# check that OTC is not set
				otc = int(self.read_debugfs(name, "OTC"))
				self.assertEqual(otc, 0, name + ": OTC is not 0")
		finally:
			self.audio.stop_silence_loop()


	@unittest.skipIf(skip_calibration_tests, "skip test to avoid MTP wear out")
	def test_debugfs_calibrate_once(self):
		if not self.info.dsp_device():
			print "debugfs calibration requires a DSP"
			return

		self.audio.start_silence_loop(48000, 2, 16, 600)

		# make sure we stop the silence playback thread when something goes wrong
		try:
			time.sleep(4)

			for name in self.info.device_names:

				# read old calibration value(s)
				R = self.read_debugfs(name, "R")
				cal1 = self.parse_calibration_values(R)

				# initiate calibration
				self.write_debugfs(name, "MTPEX", "0")
				self.write_debugfs(name, "OTC", "1")
				self.write_debugfs(name, "calibrate", "please calibrate now")

				# give the device some time to do calibration
				time.sleep(5)

				# read new calibration value(s)
				R = self.read_debugfs(name, "R")
				cal2 = self.parse_calibration_values(R)

				# check calibration value(s) has/have changed
				# assuming that both values are not exactly the same, but in
				# theory they can be the same and we can get a false positive
				for value1, value2 in zip(cal1, cal2):
					self.assertNotEqual(value1, value2, name + ": calibration value not changed")

				# check that MTPEX is set
				mtpex = int(self.read_debugfs(name, "MTPEX"))
				self.assertEqual(mtpex, 1, name + ": MPTEX is not 1")

				# check that OTC is set
				otc = int(self.read_debugfs(name, "OTC"))
				self.assertEqual(otc, 1, name + ": OTC is not 1")
		finally:
			self.audio.stop_silence_loop()


if __name__ == '__main__':
	unittest.main()

