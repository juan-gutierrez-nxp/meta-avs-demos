#!/bin/bash

# Script to load device tree overlay for the TFA9872
# depending on the argument, a mono or stereo device tree overlay will be used

SLOTS=/sys/devices/platform/bone_capemgr/slots

if [ ! -f "$SLOTS" ];
then
	echo "Device tree overlays are not supported!!!"
	exit 1
fi

if [ "$1" != "mono" ];
then
	if [ "$1" != "stereo" ];
	then
		echo "Usage: $0 <mono/stereo>"
		exit 1
	fi
fi

CH=$1
DEVICE=tfa9872
OVERLAY=$DEVICE-$CH

# remove load overlay if already loaded
TFA_SLOT=$(cat $SLOTS | grep tfa | awk '{gsub(":",""); print $1}')
if [ -n "$TFA_SLOT" ];
then
	cat $SLOTS

	echo "Removing overlay "$TFA_SLOT

	# remove modules first (or get ready for a kernel crash):
	rmmod snd_soc_bbb_nxp_tfa
	rmmod snd_soc_tfa98xx
	rmmod snd_soc_davinci_mcasp
	rmmod clk_cdce906

	# remove overlay
	echo -$TFA_SLOT > $SLOTS
fi

echo "Inserting overlay "$OVERLAY
echo  $OVERLAY> $SLOTS

cat $SLOTS

# Wait, so modules can be loaded by the kernel
sleep 1

# Remove modules, since device tree overlay might loads with default container
# file, which might not be what we want
rmmod snd-soc-bbb-nxp-tfa
rmmod snd-soc-tfa98xx

CNT=tfa98/72/$CH.cnt

# load modules again
modprobe snd-soc-tfa98xx fw_name=$CNT trace_level=1
modprobe snd-soc-bbb-nxp-tfa

alias cl='climax -dsysfs -l /lib/firmware/'$CNT

