#!/bin/bash

# Script to load device tree overlays for the TFA devices on BBB
# argument is the name of the device tree overlay.
# e.g.: ./load_bbb_tfa_overlay.sh tfa9872-stereo
#
# Note: the user of this script needs to make sure the correct default
#        container file is set in /lib/firmware/tfa98xx.cnt or
#        defined in /etc/modprobe.d/tfa98xx.conf

SLOTS=/sys/devices/platform/bone_capemgr/slots

if [ ! -f "$SLOTS" ];
then
	echo "Device tree overlays are not supported!!!"
	exit 1
fi

if [ $# -lt 1 ];
then
	echo "Usage: $0 <overlay>"
	exit 1
fi

OVERLAY=$1

# remove load overlay if already loaded
TFA_SLOT=$(cat $SLOTS | grep tfa | awk '{gsub(":",""); print $1}')
if [ -n "$TFA_SLOT" ];
then
	cat $SLOTS

	echo "Removing overlay "$TFA_SLOT

	# remove modules first (or get ready for a kernel crash):
	rmmod snd-soc-tfa98xx-ext # just in case
	rmmod snd_soc_bbb_nxp_tfa
	rmmod snd_soc_tfa98xx
	rmmod snd_soc_davinci_mcasp
	rmmod clk_cdce906

	# remove overlay
	echo -$TFA_SLOT > $SLOTS
fi

echo "Inserting overlay "$OVERLAY
echo  $OVERLAY> $SLOTS

cat $SLOTS

